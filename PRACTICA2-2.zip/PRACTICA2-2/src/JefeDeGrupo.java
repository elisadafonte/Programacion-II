import java.time.LocalDate;
import java.util.ArrayList;

public class JefeDeGrupo extends Tecnico{
    private String nombreEquipo;
    private ArrayList<Tecnico> equipo;

    public JefeDeGrupo(String nombre, String telefono, LocalDate fechaNacimiento, String dni, CuentaBancaria cuentaBancaria, String nombreEquipo) {
        super(nombre, telefono, fechaNacimiento, dni, cuentaBancaria);
        this.nombreEquipo=nombreEquipo;
        equipo = new ArrayList<>();
    }

    public String getNombreEquipo() {

        return nombreEquipo;
    }

    public void setNombreEquipo(String nombreEquipo) {

        this.nombreEquipo = nombreEquipo;
    }

    public ArrayList<Tecnico> getEquipo() {

        return equipo;
    }

    public void setEquipo(ArrayList<Tecnico> equipo) {

        this.equipo = equipo;
    }

    public void agregarTecnico(Tecnico tecnico){

        equipo.add(tecnico);
    }

    public boolean existeTecnico(Tecnico tecnico){
        for (Tecnico t : equipo){
            if (t.getDni().equals(tecnico.getDni())){
                return true;

            }
        }
        return false;
    }

    public void eliminarTecnico(Tecnico tecnico){

        equipo.remove(tecnico);
    }

}

