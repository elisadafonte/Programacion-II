import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    private static ArrayList<Persona> empleados;
    static Scanner teclado = new Scanner(System.in);


    public static void main(String[] args) {
        empleados = new ArrayList<>();
        //Scanner teclado = new Scanner(System.in);
        int opcion = 4;

        while (opcion != 0) {
            opcion = mostrarMenu();
            switch (opcion) {
                case 0:
                    System.out.println("Cerrando el programa");
                    break;
                case 1:
                    altaContrato();
                    break;
                case 2:
                    bajaContrato();
                    break;
                case 3:
                    agregarTecnico();
                    break;
                case 4:
                    quitarTecnico();
                    break;
                case 5:
                    anadirHorasExtra();
                    break;
                case 6:
                    listaEmpleadosActuales();

                    break;
                case 7:
                    listaEmpleadosBaja();
                    break;
                case 8:
                    listaEmpleadosAdmin();
                    break;
                case 9:
                    listaEquipos();
                    break;
                case 10:
                    generarNomina();
                    break;
                case 11:
                    listaNominas();
                    break;

            }
        }
    }

    private static int mostrarMenu() {
        int opcion = 4;
        do {
            System.out.println("------Gestor de nominas------");
            System.out.println("1.Dar de Alta un contrato");
            System.out.println("2.Dar de Baja un contrato");
            System.out.println("3.Añadir un tecnico al equipo");
            System.out.println("4.Quitar un tecnico del equipo");
            System.out.println("5.Añadir horas extra a un empleado ");
            System.out.println("6.Listado de los empelados activos");
            System.out.println("7.Listado de los empleados dados de baja ");
            System.out.println("8.Listado de empelados de administracion");
            System.out.println("9.Listado de equipos");
            System.out.println("10.Generar nomina de un empleado");
            System.out.println("11.Generar todas las nominas para un mes y año");
            System.out.println("0.Salir");
            System.out.print("Introduzca la opcion que desee: ");
            try {
                opcion = teclado.nextInt();
                if (opcion < 0 || opcion > 11) {
                    System.out.println("La opcion es invalida. ");
                }
            } catch (Exception e) {
                System.out.println("La opcion debe ser un valor numerico");
            }

        } while (opcion < 0 || opcion > 11);
        return opcion;

    }

    public static void altaContrato() {
        System.out.print("Introduzca el dni: ");
        teclado.next();
        String dni;
        dni= teclado.nextLine();
        if (buscarEmpleado(dni) != null) {
            System.out.println("El empleado ya existe");
        } else {
            System.out.print("Introduzca el nombre: ");
            String nombre = teclado.nextLine();
            System.out.print("Introduzca el numero de telefono: ");
            String telefono = teclado.nextLine();
            System.out.println("A continuacion introduzca la fecha de nacimiento.");
            LocalDate fechaNacimiento = pedirFecha();
            System.out.print("Introduzca el nombre de entidad: ");
            teclado.next();
            String nombreEntidad = teclado.nextLine();
            System.out.print("Introduzca el iban: ");
            String iban = teclado.nextLine();
            CuentaBancaria cuentaBancaria = new CuentaBancaria(nombreEntidad, iban);

            int tipoEmpleado = 0;
            Persona empleado = null;
            do {
                System.out.print("Indique el tipo de empleado(0.Tecnico, 1.Admistracion, 2.Jefe de Grupo): ");
                tipoEmpleado = teclado.nextInt();

                switch (tipoEmpleado) {
                    case 0:
                        empleado = new Tecnico(nombre, telefono, fechaNacimiento, dni, cuentaBancaria);
                        break;
                    case 1:
                        empleado = new Administracion(nombre, telefono, fechaNacimiento, dni, cuentaBancaria);
                        break;
                    case 2:
                        System.out.print("Introduzca el nombre del equipo: ");
                        teclado.next();
                        String nombreEquipo = teclado.nextLine();
                        empleado = new JefeDeGrupo(nombre, telefono, fechaNacimiento, dni, cuentaBancaria, nombreEquipo);
                        break;

                    default:
                        System.out.println("Opcion invalida");
                        break;

                }
            } while (tipoEmpleado < 0 || tipoEmpleado > 2);//ahora solicitar datos del contrato


            System.out.print("Introduzca el puesto: ");
            teclado.next();
            String puesto = teclado.nextLine();
            System.out.print("Introduzca el Salario Base: ");
            double salarioBase = teclado.nextDouble();
            System.out.println("A continuacion introduzca la fecha de Alta.");
            LocalDate fechaAlta = pedirFecha();
            System.out.print("Introuzca el IRPF (porcentaje):");
            double irpf = teclado.nextDouble();


            int eleccion = 0;

            do {
                System.out.print("Elija si es un contrato definido (1) o indefinido (2): ");
                eleccion = teclado.nextInt();

                switch (eleccion) {
                    case 1:
                        System.out.print("Introduzca la fecha de baja: ");
                        LocalDate fechaBaja = pedirFecha();
                        Contrato contrato1 = new Contrato(puesto, salarioBase, fechaAlta, fechaBaja);
                        empleado.setContrato(contrato1);
                        Deducciones deduccion = new Deducciones(irpf);
                        empleado.getContrato().setDeducciones(deduccion);
                        break;
                    case 2:
                        Contrato contrato2 = new Contrato(puesto, salarioBase, fechaAlta);
                        empleado.setContrato(contrato2);
                        Deducciones deduccion2 = new Deducciones(irpf);
                        empleado.getContrato().setDeducciones(deduccion2);
                        break;

                    default:
                        System.out.println("Opcion invalida");
                        break;

                }
            } while (eleccion < 0 || eleccion > 2);

            empleados.add(empleado);

        }

    }

    private static void bajaContrato(){
        System.out.print("Introduzca el dni:");
        String dni = teclado.nextLine();
        Persona empleado = buscarEmpleado(dni);
        if (empleado == null) {
            System.out.println("El empleado no existe");
        } else {
            System.out.print("Introduzca la fecha de baja : ");
            LocalDate fechaBaja = pedirFecha();
            empleado.getContrato().setFechaBaja(fechaBaja);
        }
    }

    private static void agregarTecnico() {

        System.out.print("Introduzca el nombre del equipo: ");
        teclado.nextLine();
        String nombreEquipo = teclado.nextLine();
        System.out.print("Introduzca el dni del tecnico: ");
        String dni= teclado.nextLine();
        JefeDeGrupo jefeDeGrupo= buscarEquipo(nombreEquipo);
        if (jefeDeGrupo== null){
            System.out.println("No existe un equipo con ese nombre ");

        }
        else {
            Persona persona = buscarEmpleado(dni) ;
            if (persona == null){
                System.out.println("No existe ningun trabajador con ese dni");

            }
            else {
                if (persona instanceof Tecnico){
                    if (jefeDeGrupo.existeTecnico((Tecnico) persona)){
                        System.out.println("Ese tecnico ya pertenece a ese equipo");
                    }
                    else{
                        jefeDeGrupo.agregarTecnico((Tecnico) persona);
                        System.out.println("Se ha agregad el tecnico con exito");
                    }
                }
                else {
                    System.out.println("Ese dni no corresponde a un tecnico");
                }
            }
        }
    }

    private static void quitarTecnico() {
        System.out.println("Introduzca el nombre del equipo: ");
        String nombreEquipo = teclado.nextLine();
        JefeDeGrupo jefeDeGrupo= buscarEquipo(nombreEquipo);
        if (jefeDeGrupo== null){
            System.out.println("No existe un equipo con ese nombre ");

        }
        else {
            System.out.println("Introduzca el dni del tecnico: ");
            String dni= teclado.nextLine();
            Persona persona = buscarEmpleado(dni) ;
            if (persona == null){
                System.out.println("No existe ningun trabajador con ese dni");

            }
            else {
                if (persona instanceof Tecnico){
                    if (jefeDeGrupo.existeTecnico((Tecnico) persona)){
                        jefeDeGrupo.eliminarTecnico((Tecnico) persona);
                        System.out.println("Se ha elimiando el tecnico correctamente");
                    }
                    else{

                        System.out.println("Ese tecnico no pertenece a ese equipo");
                    }
                }
                else {
                    System.out.println("Ese dni no corresponde a un tecnico");
                }
            }
        }
    }

    private static void anadirHorasExtra() {
        System.out.println("Introduzca el dni: ");
        String dni= teclado.nextLine();
        Persona persona =buscarEmpleado(dni);
        if (persona == null){
            System.out.println("No existe una persona con ese dni");
        }
        else {

            int mes = pedirMes();
            int anio= pedirAnio(2020,2025);
            System.out.println("Introduzca el numero de horas extra: ");
            int numero= teclado.nextInt();
            HorasExtra horasExtra = new HorasExtra(mes,anio, numero);
            persona.getContrato().anadirHorasExtra(horasExtra);
            System.out.println("Registradas correctamnete las horas extra");


        }

    }

    private static void listaEmpleadosActuales() {
        LocalDate hoy = LocalDate.now();
        if (empleados.isEmpty()){
            System.out.println("No hay empleados registrados.");
        }
        else {
            System.out.println("Listado de empelados actuales: ");
            for (Persona p : empleados) {
                if (!p.getContrato().deBaja(hoy.getMonthValue(),hoy.getYear())) {

                    System.out.print(p.getNombre() + ", ");
                    if (p instanceof Administracion){
                        System.out.print("Administracion, ");
                    }
                    if (p instanceof JefeDeGrupo){
                        System.out.print("Jefe de Grupo, ");
                    }
                    if (p instanceof Tecnico){
                        System.out.print("Tecnico, ");
                    }
                    System.out.print(p.getContrato().getPuesto() + ", "
                    + p.getContrato().getFechaAlta());

                }

            }
        }
    }
    private static void listaEmpleadosBaja() {
        LocalDate hoy = LocalDate.now();
        if (empleados.isEmpty()){
            System.out.println("No hay empleados registrados.");
        }
        else {
            System.out.println("Listado de empelados de baja: ");
            for (Persona p : empleados) {
                if (p.getContrato().deBaja(hoy.getMonthValue(),hoy.getYear())) {

                    System.out.print(p.getNombre() + ", ");
                    if (p instanceof Administracion){
                        System.out.print("Administracion, ");
                    }
                    if (p instanceof JefeDeGrupo){
                        System.out.print("Jefe de Grupo, ");
                    }
                    if (p instanceof Tecnico){
                        System.out.print("Tecnico, ");
                    }
                    System.out.println(p.getContrato().getPuesto() + ", "
                    + p.getContrato().getFechaAlta() + ", "+ p.getContrato().getFechaBaja());

                }

            }
        }
    }

    private static void listaEmpleadosAdmin() {
        LocalDate hoy = LocalDate.now();
        if (empleados.isEmpty()){
            System.out.println("No hay empleados registrados.");
        }
        else {
            System.out.println("Listado de empelados de Administracion: ");
            for (Persona p : empleados) {
                if (p instanceof Administracion) {

                    System.out.println(p.getNombre() + ", "+ p.getContrato().getPuesto());

                }

            }
        }
    }

    private static void listaEquipos (){
        LocalDate hoy = LocalDate.now();
        if (empleados.isEmpty()){
            System.out.println("No hay empleados registrados.");
        }
        else {
            System.out.println("Listado de equipos: ");
            for (Persona p : empleados) {
                if (p instanceof JefeDeGrupo) {

                    System.out.println("\n"+((JefeDeGrupo) p).getNombreEquipo()+ ": ");
                    System.out.println("Jefe de Equipo: "+p.getNombre());
                    for (int i = 0; i < ((JefeDeGrupo) p).getEquipo().size(); i++) {
                        System.out.println(i+1 + ((JefeDeGrupo) p).getEquipo().get(i).getNombre());
                    }

                }

            }
        }
    }

    private static void generarNomina (){
        System.out.println("Introduzca el dni: ");
        teclado.next();
        String dni= teclado.nextLine();
        Persona p =buscarEmpleado(dni);
        p.getContrato().establecerTrienios();
        if (p == null){
            System.out.println("No existe una persona con ese dni");
        }
        else {
            int mes = pedirMes();
            int anio= pedirAnio(2020,2025);
            double porTrienios = (p.getContrato().getSalarioBase()/12)*p.getContrato().getComplementos().getTrienios();
            double porHorasExtras = p.getContrato().getComplementos().buscarHorasExtra(mes,anio)*25;
            double porJefe = 0;
            if (p instanceof JefeDeGrupo){
                porJefe = (((JefeDeGrupo) p).getEquipo().size()*(p.getContrato().getSalarioBase()*0.015));
            }
            double subtotal =p.getContrato().getSalarioBase()+porTrienios+porHorasExtras+porJefe;
            double irpf = subtotal * (p.getContrato().getDeducciones().getIrpf()/100);
            double desempleo = subtotal *0.016;
            double contingencias = subtotal *0.047;
            double total = subtotal - irpf- desempleo- contingencias;

            System.out.println(p.getNombre()+" "+p.getDni());
            System.out.println("Cuenta: " + p.getCuenta());
            System.out.println("Puesto: "+ p.getContrato().getPuesto());
            System.out.println("Salario mes:       "+p.getContrato().getSalarioBase()+"€");
            System.out.println("+Por trienios:     "+porTrienios+ "€");
            System.out.println("+Horas extra:      "+ porHorasExtras+ "€");
            System.out.println("+Por jefe:          "+porJefe+"€");
            System.out.println("-IRPF:              "+irpf+"€");
            System.out.println("-Desempleo:         "+desempleo+"€");
            System.out.println("-Contingencias:     "+contingencias+ "€");
            System.out.println("A percibir:          "+total+"€");


        }
    }

    private static void listaNominas() {
        if (empleados.isEmpty()){
            System.out.println("No hay empleados registrados.");
        }
        else {
            int mes = pedirMes();
            int anio= pedirAnio(2020,2025);
            System.out.println("Listado de nominas: ");
            for (Persona p : empleados) {
                if (!p.getContrato().deBaja(mes,anio)) {

                    double porTrienios = (p.getContrato().getSalarioBase()/12)*p.getContrato().getComplementos().getTrienios();
                    double porHorasExtras = p.getContrato().getComplementos().buscarHorasExtra(mes,anio)*25;
                    double porJefe = 0;
                    if (p instanceof JefeDeGrupo){
                        porJefe = (((JefeDeGrupo) p).getEquipo().size()*(p.getContrato().getSalarioBase()*0.015));
                    }
                    double subtotal =p.getContrato().getSalarioBase()+porTrienios+porHorasExtras+porJefe;
                    double irpf = subtotal * (p.getContrato().getDeducciones().getIrpf()/100);
                    double desempleo = subtotal *0.016;
                    double contingencias = subtotal *0.047;
                    double total = subtotal - irpf- desempleo- contingencias;

                    System.out.println(p.getNombre()+" "+p.getDni());
                    System.out.println("Cuenta: " + p.getCuenta());
                    System.out.println("Puesto: "+ p.getContrato().getPuesto());
                    System.out.println("Salario mes:       "+p.getContrato().getSalarioBase()+"€");
                    System.out.println("+Por trienios:     "+porTrienios+ "€");
                    System.out.println("+Horas extra:      "+ porHorasExtras+ "€");
                    System.out.println("+Por jefe:          "+porJefe+"€");
                    System.out.println("-IRPF:              "+irpf+"€");
                    System.out.println("-Desempleo:         "+desempleo+"€");
                    System.out.println("-Contingencias:     "+contingencias+ "€");
                    System.out.println("A percibir:          "+total+"€");

                }

            }
        }
    }

    private static JefeDeGrupo buscarEquipo(String nombreEquipo){
        for (Persona p: empleados){
            if (p instanceof JefeDeGrupo ){
                if (((JefeDeGrupo)p).getNombreEquipo().equalsIgnoreCase(nombreEquipo)){
                    return (JefeDeGrupo)p;

                }
            }
        }
        return null;
    }

    private static Persona buscarEmpleado(String dni) {
        for (Persona p : empleados) {
            if (p.getDni().equalsIgnoreCase(dni)) {
                return p;
            }

        }
        return null;
    }


    private static int pedirMes(){
        int mes=0;
        boolean continuar = true;
        while (continuar) {
            System.out.print("Introduzca el mes: ");
            mes = teclado.nextInt();
            if (mes < 1 || mes > 12) {
                System.out.println("Mes invalido");
            } else {
                continuar = false;
            }
        }
        return mes;
    }

    private static int pedirAnio(int valorMin, int valorMax){
        int anio =0;
        boolean continuar = true;
        while (continuar) {
            System.out.print("Introduzca el anio: ");
            anio = teclado.nextInt();
            if (anio < valorMin || anio > valorMax) {
                System.out.println("Anio invalido");
            } else {
                continuar = false;
            }
        }
        return anio;
    }

    private static LocalDate pedirFecha(){
        boolean continuar = true;
        LocalDate localDate = null;
        do {

            int dia=0;
            int mes=0;
            int anio=0;

            while (continuar) {
                System.out.print("Introduzca el dia: ");
                dia = teclado.nextInt();
                if (dia < 1 || dia > 31) {
                    System.out.print("Dia invalido");
                } else {
                    continuar = false;
                }
            }
            mes=pedirMes();
            anio=pedirAnio(1900,2025);

            continuar=true;

            try {
                localDate = LocalDate.of(anio, mes, dia);
                continuar = false;


            } catch (Exception e) {
                System.out.println("Fecha invalida");
            }
        } while (continuar);
        return localDate;

    }

}