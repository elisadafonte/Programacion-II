import java.time.LocalDate;

public class Contrato {
    private String puesto;
    private double salarioBase; //BRUTO ANUAL
    private LocalDate fechaAlta;
    private LocalDate fechaBaja;
    private Complementos complementos;
    private Deducciones deducciones;


    public Contrato(String puesto, double salarioBase, LocalDate fechaAlta) {
        setPuesto(puesto);
        setSalarioBase(salarioBase);
        setFechaAlta(fechaAlta);
        setFechaBaja(null);
    }

    public Contrato(String puesto, double salarioBase, LocalDate fechaAlta, LocalDate fechaBaja) {
        setPuesto(puesto);
        setSalarioBase(salarioBase);
        setFechaAlta(fechaAlta);
        setFechaBaja(fechaBaja);
    }

    public void anadirHorasExtra(HorasExtra horasExtra){
        establecerTrienios();
        this.complementos.getHorasExtra().add(horasExtra);
    }

    public void establecerTrienios (){
        LocalDate hoy = LocalDate.now();
        int anios = hoy.getYear()- fechaAlta.getYear();
        if (hoy.getMonthValue() < fechaAlta.getMonthValue() ||
                (hoy.getMonthValue() == fechaAlta.getMonthValue()
                        && hoy.getDayOfMonth() < fechaAlta.getDayOfMonth())) {
            anios--;
        }
        int trienios = (int)(anios/3);
        Complementos complemento = new Complementos(trienios);
        setComplementos(complemento);
    }

    public void modificarComplemento(int mes, int anio, int numero){
        establecerTrienios();

        for (int i = 0; i < this.complementos.getHorasExtra().size(); i++) {
            if((mes == this.complementos.getHorasExtra().get(i).getMes())
                    &&(anio == this.complementos.getHorasExtra().get(i).getAnio())){
                this.complementos.getHorasExtra().get(i).setNumero(numero);
            }
        }

    }

    public void anadirIrpf(double irpf){
        this.deducciones.setIrpf(irpf);
    }
    public void anadirDeduccion(double irpf,int mes, int anio, int numero){
        this.deducciones.setIrpf(irpf);
        DiasBaja periodoBaja = new DiasBaja(mes, anio, numero);
        this.deducciones.setPeriodoBaja(periodoBaja);
    }

    public void modificarIrpf(double irpf){
        this.deducciones.setIrpf(irpf);
    }
    public void modificarDeduccion(double irpf, int mes, int anio, int numero){
        for (int i = 0; i < this.deducciones.getPeriodoBaja().size(); i++) {
            if((mes == this.deducciones.getPeriodoBaja().get(i).getMes())
                    &&(anio == deducciones.getPeriodoBaja().get(i).getAnio())){
                this.deducciones.getPeriodoBaja().get(i).setNumero(numero);
            }
        }

    }

    public boolean deBaja (int mes, int anio){

        for (int i = 0; i < this.deducciones.getPeriodoBaja().size(); i++) {
            if((mes == this.deducciones.getPeriodoBaja().get(i).getMes())
                    &&(anio== deducciones.getPeriodoBaja().get(i).getAnio())){
                return true;
            }
        }
        return false;
    }

    public String getPuesto() {
        return puesto;
    }

    public void setPuesto(String puesto) {
        this.puesto = puesto;
    }

    public double getSalarioBase() {
        return salarioBase;
    }

    public void setSalarioBase(double salarioBase) {
        this.salarioBase = salarioBase;
    }

    public LocalDate getFechaAlta() {
        return fechaAlta;
    }

    public void setFechaAlta(LocalDate fechaAlta) {
        this.fechaAlta = fechaAlta;
    }

    public LocalDate getFechaBaja() {
        return fechaBaja;
    }

    public void setFechaBaja(LocalDate fechaBaja) {
        this.fechaBaja = fechaBaja;
    }

    public Complementos getComplementos() {
        return complementos;
    }

    public void setComplementos(Complementos complementos) {
        this.complementos = complementos;
    }

    public Deducciones getDeducciones() {
        return deducciones;
    }

    public void setDeducciones(Deducciones deducciones) {
        this.deducciones = deducciones;
    }
}
