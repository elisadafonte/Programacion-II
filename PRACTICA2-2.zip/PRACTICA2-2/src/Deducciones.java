import java.util.ArrayList;

public class Deducciones {
    private double irpf;
    private ArrayList<DiasBaja> periodoBaja = new ArrayList<>();

    public Deducciones(double irpf, DiasBaja periodoBaja) {
        setIrpf(irpf);
        setPeriodoBaja(periodoBaja);
    }

    public Deducciones(double irpf) {
        setIrpf(irpf);
    }

    public double getIrpf() {
        return irpf;
    }

    public void setIrpf(double irpf) {
        this.irpf = irpf;
    }

    public ArrayList<DiasBaja> getPeriodoBaja() {

        return periodoBaja;
    }

    public void setPeriodoBaja(DiasBaja periodoBaja) {

        this.periodoBaja.add(periodoBaja);
    }

}
