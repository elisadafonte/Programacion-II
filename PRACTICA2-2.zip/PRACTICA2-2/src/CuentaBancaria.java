public class CuentaBancaria {
    private String nombreEntidad;
    private String iban;

    public CuentaBancaria(String nombreEntidad, String iban) {
        setNombreEntidad(nombreEntidad);
        setIban(iban);
    }

    public String getIban() {
        return iban;
    }

    public void setIban(String iban) {
        this.iban = iban;
    }

    public String getNombreEntidad() {
        return nombreEntidad;
    }

    public void setNombreEntidad(String nombreEntidad) {
        this.nombreEntidad = nombreEntidad;
    }
}
