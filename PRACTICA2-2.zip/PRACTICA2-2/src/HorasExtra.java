public class HorasExtra {
    private int mes;
    private int anio;
    private int numero;

    public HorasExtra(int mes, int anio, int numero) {
        setMes(mes);
        setAnio(anio);
        setNumero(numero);
    }

    public int getMes() {
        return mes;
    }

    public void setMes(int mes) {
        this.mes = mes;
    }

    public int getAnio() {
        return anio;
    }

    public void setAnio(int anio) {
        this.anio = anio;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }
}
