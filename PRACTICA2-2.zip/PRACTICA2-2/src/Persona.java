import java.time.LocalDate;

public abstract class Persona {
    protected String nombre;
    protected String telefono;
    protected LocalDate fechaNacimiento;
    protected String dni;
    protected CuentaBancaria cuenta;
    protected Contrato contrato;

    public Persona(String nombre, String telefono, LocalDate fechaNacimiento, String dni, CuentaBancaria cuenta) {
        setNombre(nombre);
        setTelefono(telefono);
        setFechaNacimiento(fechaNacimiento);
        setDni(dni);
        setCuenta(cuenta);
    }


    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public LocalDate getFechaNacimiento() {
        return fechaNacimiento;
    }

    public void setFechaNacimiento(LocalDate fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public CuentaBancaria getCuenta() {
        return cuenta;
    }

    public void setCuenta(CuentaBancaria cuenta) {
        this.cuenta = cuenta;
    }

    public Contrato getContrato() {
        return contrato;
    }

    public void setContrato(Contrato contrato) {
        this.contrato = contrato;
    }


}
