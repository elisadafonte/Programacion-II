import java.util.ArrayList;

public class Complementos {
    private int trienios;
    private ArrayList<HorasExtra> horasExtra = new ArrayList<>();

    public Complementos(int trienios, HorasExtra horasExtra) {
        setTrienios(trienios);
        setHorasExtra(horasExtra);
    }

    public Complementos(int trienios) {
        setTrienios(trienios);
    }

    public int getTrienios() {

        return trienios;
    }

    public void setTrienios(int trienios) {

        this.trienios = trienios;
    }

    public ArrayList<HorasExtra> getHorasExtra() {

        return horasExtra;
    }

    public void setHorasExtra(HorasExtra horasExtra) {

        this.horasExtra.add(horasExtra);

    }

    public int buscarHorasExtra (int mes, int anio){
        int totalExtras =0;
        for (int i = 0; i < this.getHorasExtra().size(); i++) {
            if (this.getHorasExtra().get(i).getMes()==mes
            && this.getHorasExtra().get(i).getAnio()==anio){
                totalExtras+= this.getHorasExtra().get(i).getNumero();
            }

        }
        return totalExtras;
    }
}

