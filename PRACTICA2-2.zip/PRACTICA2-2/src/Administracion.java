import java.time.LocalDate;

public class Administracion extends Persona{

    public Administracion(String nombre, String telefono, LocalDate fechaNacimiento, String dni, CuentaBancaria cuenta) {
        super(nombre, telefono, fechaNacimiento, dni, cuenta);
    }
}
