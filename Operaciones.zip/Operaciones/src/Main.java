//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {


        //PRIMER APARTADO
        int num1 = 1;
        int num2 = 2;

        int suma = num1 + num2;
        System.out.println("La suma de " + num1 + " y " + num2 + " es " + suma);

        int diferencia = num1 - num2;
        System.out.println("La diferencia entre " + num1 + " y " + num2 + " es " + diferencia);

        int producto = num1*num2;
        System.out.println("El producto de " + num1 + " y " + num2 + " es " + producto);

        int division =num2/num1;
        System.out.println("La division de " + num2 + " entre " + num1 + " es " + division);

        int modulo = num1%num2;
        System.out.println("El modulo de " + num1 + " y " + num2 + " es " + modulo);


        //SEGUNDO APARTADO
        int num = 2;
        double numDoub = 3.2;

        System.out.println("La suma de " + num + " y " + numDoub + " es " + (num+numDoub));

        System.out.println("La diferencia entre " + num + " y " + numDoub + " es " + (num - numDoub));

        System.out.println("El producto de " + num + " y " + numDoub + " es " + (num*numDoub));

        System.out.println("La division de " + num + " entre " + numDoub + " es " + (num/numDoub));

        System.out.println("El modulo de " + num + " y " + numDoub + " es " + (num%numDoub));


        //TERCER APARTADO
        boolean bool1 = true;
        boolean bool2 = false;

        System.out.println("El resultado del operador booleano Y lógico entre " + bool1  + " y " + bool2 + " es " + (bool1 && bool2));

        System.out.println("El resultado del operador booleano O lógico entre " + bool1  + " y " + bool2 + " es " + (bool1 || bool2));

        System.out.println("El resultado del operador booleano de negación de " + bool1  + " es " + (! bool1));


        //CUARTO APARTADO
        char c1 = 'a';
        char c2 = 'b';
        System.out.println("La primera variable char es " + c1);
        System.out.println("La segunda variable char es " + c2);
        System.out.println("La primera variable char es " + c1 + " seguida de " + c2);


    }
}