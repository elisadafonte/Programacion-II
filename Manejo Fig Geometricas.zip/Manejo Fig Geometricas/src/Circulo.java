public class Circulo {
    private double radio;

    final double PI = 3.1415926536;

    public Circulo(double radio) throws Exception {
        setRadio(radio);
    }

    public double perimetro (){
        return (2 * PI * radio);
    }

    public double area (){
        return (PI*radio*radio);
    }

    public double getRadio() {
        return radio;
    }

    public void setRadio(double radio) throws Exception {
        if (radio>0) {
            this.radio = radio;
        }
        else {
            throw new Exception("Circulo: radio negativo");
        }
        }

    @Override
    public String toString() {
        return "Circulo: " +
                "[r = " + radio +
                "]";
    }
}
