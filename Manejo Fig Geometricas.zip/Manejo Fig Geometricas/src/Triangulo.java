public class Triangulo {
    double lado1;
    double lado2;
    double lado3;

    public Triangulo(double lado1, double lado2, double lado3) throws Exception {
        setLado1(lado1);
        setLado2(lado2);
        setLado3(lado3);
    }

    public Triangulo(double lado1, double lado2) throws Exception {
        setLado1(lado1);
        setLado2(lado2);
        setLado3(lado1);
    }

    public Triangulo(double lado1) throws Exception {
        setLado1(lado1);
        setLado2(lado1);
        setLado3(lado1);
    }

    public double perimetro () {
        return (this.lado1+this.lado2+this.lado3);
    }

    public double area () {
        double semiperimetro = (this.lado1+this.lado2+this.lado3)/2;
        double altura = Math.sqrt(semiperimetro*(semiperimetro-this.lado1)*(semiperimetro-this.lado2)*(semiperimetro-this.lado3));
        return ((this.lado2*altura)/2);
    }

    public double getLado1() {
        return lado1;
    }

    public boolean esEquilatero (){
        if (lado1==lado2 && lado2==lado3 && lado1==lado3){
            return true;
        }
        else {
            return false;
        }
    }

    public boolean esIsosceles (){
        if ((lado1==lado2 && lado2 != lado3 && lado1 != lado3)
            ||(lado1==lado3 && lado2 != lado3 && lado1 != lado2)
            ||(lado3==lado2 && lado2 != lado1 && lado1 != lado3)){
            return true;
        }
        else {
            return false;
        }
    }

    public boolean esEscaleno () {
        if (lado1!=lado2 && lado2 !=lado3 && lado3!=lado1){
            return true;
        }
        else {
            return false;
        }
    }

    public void setLado1(double lado1) throws Exception {
        if (lado1>0) {
            this.lado1 = lado1;
        }
        else {
            throw new Exception("Triangulo: lado negativo");
        }
    }

    public double getLado2() {
        return lado2;
    }

    public void setLado2(double lado2) throws Exception {
        if (lado2>0) {
            this.lado2= lado2;
        }
        else {
            throw new Exception("Triangulo: lado negativo");
        }
    }

    public double getLado3() {
        return lado3;
    }

    public void setLado3(double lado3) throws Exception {
        if (lado3>0) {
            this.lado3 = lado3;
        }
        else {
            throw new Exception("Triangulo: lado negativo");
        }
    }

    @Override
    public String toString() {
        return "Triangulo: " +
                "[" + lado1 +
                " - " + lado2 +
                " - " + lado3 +
                "]";
    }
}
