public class Rectangulo {
    private double lado1;
    private double lado2;

    public Rectangulo(double lado1, double lado2) throws Exception {
        setLado1(lado1);
        setLado2(lado2);
    }

    public Rectangulo(Double lado1) {
        this.lado1 = lado1;
        this.lado2=lado1;
    }

    public double area (){
        return (lado1*lado2);
    }

    public double perimetro () {
        return ((lado1*2)+(lado2*2));
    }

    public boolean esCuadrado(){
        if (lado1 == lado2){
            return true;
        }
        else {
            return false;
        }
    }

    public double getLado1() {
        return lado1;
    }

    public void setLado1(double lado1) throws Exception {
        if (lado1>0) {
            this.lado1 = lado1;
        }
        else {
            throw new Exception("Rectangulo:Lado negativo");
        }
    }

    public double getLado2() {
        return lado2;
    }

    public void setLado2(double lado2) throws Exception {
        if (lado2>0) {
            this.lado2 = lado2;
        }
        else {
            throw new Exception("Rectangulo:Lado negativo");
        }
    }

    @Override
    public String toString() {
        return "Rectangulo:" +
                " [" + lado1 +
                " x " + lado2 +
                "]";
    }
}
