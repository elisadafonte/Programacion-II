import java.util.Scanner;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {

        Scanner teclado = new Scanner(System.in);

        System.out.println("---BIENVENIDO AL PROGRAMA---");
        int opcion = -1;
        while (opcion !=0) {
            System.out.println("---MENU---" +
                    "\n 1. Rectangulo" +
                            "\n 2. Circulo" +
                            "\n 3. Triangulo" +
                            "\n 0. Salir");
            System.out.print("Elija una opcion: ");
            opcion = teclado.nextInt();
            switch (opcion) {
                case 1: {
                    double lado1;
                    double lado2;

                    System.out.print("Ingrese el valor del primer lado: ");
                    lado1 = teclado.nextDouble();
                    System.out.print("Ingrese el valor del segundo lado: ");
                    lado2 = teclado.nextDouble();

                    try {
                        Rectangulo rectangulo;
                        if (lado1 != lado2){
                            rectangulo = new Rectangulo (lado1, lado2);
                        }
                        else {
                            rectangulo = new Rectangulo(lado1);
                        }
                        System.out.println(rectangulo + "\n Perimetro: " + rectangulo.perimetro()
                        + "\n Area: " + rectangulo.area());
                        if (rectangulo.esCuadrado()) {
                            System.out.println("Los lados son iguales, es un cuadrado");
                        }
                    } catch (Exception e) {
                        System.out.println("No se ha podido crear el Rectangulo: Lado negativo");
                    }
                    break;
                }

                case 2: {
                    double radio;

                    System.out.print("Ingrese el valor del radio: ");
                    radio = teclado.nextDouble();
                    Circulo circulo;
                    try {
                        circulo = new Circulo(radio);
                        System.out.println(circulo + "\n Perimetro: " + circulo.perimetro()
                                + "\n Area: " + circulo.area());

                    } catch (Exception e) {
                        System.out.println("No se ha podido crear el Circulo: Radio negativo");
                    }
                    break;
                }

                case 3: {
                    double lado1;
                    double lado2;
                    double lado3;

                    System.out.print("Ingrese el valor del primer lado: ");
                    lado1 = teclado.nextDouble();
                    System.out.print("Ingrese el valor del segundo lado: ");
                    lado2 = teclado.nextDouble();
                    System.out.print("Ingrese el valor del tercer lado: ");
                    lado3 = teclado.nextDouble();

                    try{
                        Triangulo triangulo = new Triangulo(lado1);

                        if (lado1 != lado2 && lado1 != lado3 && lado2 != lado3){
                            triangulo = new Triangulo (lado1, lado2, lado3);
                        }
                        if (lado1 == lado2 && lado2==lado3 && lado3 == lado1){
                            triangulo = new Triangulo(lado1);
                        }
                        else {
                            if (lado1==lado3 && lado1 != lado2) {
                                triangulo = new Triangulo(lado1, lado2);
                            }
                            if (lado1==lado2 && lado3 !=lado2){
                                triangulo = new Triangulo (lado1, lado3);
                            }
                            if (lado2 == lado3 && lado1 != lado2){
                                triangulo = new Triangulo (lado2, lado1);
                            }
                        }

                        System.out.println( triangulo + "\n Perimetro: " + triangulo.perimetro()
                                + "\n Area: " + triangulo.area());
                        if (triangulo.esEscaleno()){
                            System.out.println("El triangulo es Escaleno, tiene todos lo lados diferentes");
                        }
                        if (triangulo.esEquilatero()){
                            System.out.println("El triangulo es Equilatero, tiene todos los lados iguales");
                        }
                        if (triangulo.esIsosceles()){
                            System.out.println("El triangulo es Isosceles, tiene dos lados iguales");
                        }

                    } catch (Exception e) {
                        System.out.println("No se ha podido crear el Triangulo: Lado negativo");
                    }
                    break;
                }

                case 0: {
                    System.out.println("---HA SALIDO DEL PROGRAMA CON EXITO---");
                }

            }
        }
    }
}