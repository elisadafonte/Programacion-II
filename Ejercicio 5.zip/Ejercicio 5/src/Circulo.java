public class Circulo {
    private double radio;

    public Circulo(double radio) {
        setRadio(radio);
    }

    public double getRadio() {
        return radio;
    }

    public void setRadio(double radio) {
        this.radio = radio;
    }

    public double calcularArea (){
        double area = getRadio()*getRadio()*3.14;
        return area;
    }

    public double calcularPerimetro(){
        double perimetro = getRadio()*2*3.14;
        return perimetro;
    }
}
