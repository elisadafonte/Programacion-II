public class Triangulo {
    private double altura;
    private double base;

    public Triangulo(double altura, double base) {
        setAltura(altura);
        setBase(base);
    }

    public double getAltura() {
        return altura;
    }

    public void setAltura(double altura) {
        this.altura = altura;
    }

    public double getBase() {
        return base;
    }

    public void setBase(double base) {
        this.base = base;
    }

    public double calcularArea (){
        double area = (base*altura)/2;
        return area;
    }

    public double calcularPerimetro (){
        double lado;
        double perimetro;
        lado = Math.sqrt(((base/2)*(base/2))+(altura*altura));
        perimetro = lado*2 + base;
        return perimetro;
    }
}
