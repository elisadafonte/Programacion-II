import java.util.ArrayList;
import java.util.Random;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.



public class Main {

    public static void main(String[] args) {

        Random rand = new Random ();

        Rectangulo[] rectangulos = new Rectangulo[50];
        Triangulo[] triangulos = new Triangulo[50];
        Circulo[] circulos= new Circulo[50];

        double min = 1;
        double max = 10;

        for (int i = 0; i < 50; i++) {
            double lado1 = rand.nextDouble(max-min+1)+min;
            double lado2 = rand.nextDouble(max-min+1)+min;
            rectangulos[i] = new Rectangulo(lado1,lado2);
        }

        for (int i = 0; i < 50; i++) {
            double radio = rand.nextDouble(max-min+1)+min;
            circulos[i] = new Circulo(radio);
        }

        for (int i = 0; i < 50; i++) {
            double altura = rand.nextDouble(max-min+1)+min;
            double base = rand.nextDouble(max-min+1)+min;
            triangulos[i] = new Triangulo(altura, base);
        }

        for (int i = 0; i < 50; i++) {
            System.out.println("Para un rectangulo de lados "+rectangulos[i].getLado1()+" y "+
                    rectangulos[i].getLado2()+ " el area seria "+ rectangulos[i].calcularArea()+
                    " y el perimetro "+ rectangulos[i].calcularPerimetro());
        }

        for (int i = 0; i < 50; i++) {
            System.out.println("Para un circulo de radio "+circulos[i].getRadio()+
                    " el area seria "+ circulos[i].calcularArea()+
                    " y el perimetro "+ circulos[i].calcularPerimetro());
        }

        for (int i = 0; i < 50; i++) {
            System.out.println("Para un triangulo de base "+triangulos[i].getBase()+" y altura "+
                    triangulos[i].getAltura()+ " el area seria "+ triangulos[i].calcularArea()+
                    " y el perimetro "+ triangulos[i].calcularPerimetro());
        }

        double sumaPerimetrosRectangulos=0;
        double sumaAreasRectangulos=0;

        for (int i = 0; i < 50; i++) {
            sumaAreasRectangulos +=rectangulos[i].calcularArea();
        }
        for (int i = 0; i < 50; i++) {
            sumaPerimetrosRectangulos +=rectangulos[i].calcularPerimetro();
        }

        System.out.println("La suma de todas las areas de los rectangulos es: "+
                sumaAreasRectangulos);
        System.out.println("La media de todas las areas de los rectangulos es: "+
                (sumaAreasRectangulos/50));
        System.out.println("La suma de todos los perimetros de los rectangulos es: "+
                sumaPerimetrosRectangulos);

        double sumaPerimetrosCirculos=0;
        double sumaAreasCirculos=0;

        for (int i = 0; i < 50; i++) {
            sumaAreasCirculos +=circulos[i].calcularArea();
        }
        for (int i = 0; i < 50; i++) {
            sumaPerimetrosCirculos +=circulos[i].calcularPerimetro();
        }

        System.out.println("La suma de todas las areas de los circulos es: "+
                sumaAreasCirculos);
        System.out.println("La media de todas las areas de los circulos es: "+
                (sumaAreasCirculos/50));
        System.out.println("La suma de todos los perimetros de los circulos es: "+
                sumaPerimetrosCirculos);


        double sumaPerimetrosTriangulos=0;
        double sumaAreasTriangulos=0;

        for (int i = 0; i < 50; i++) {
            sumaAreasTriangulos+=triangulos[i].calcularArea();
        }
        for (int i = 0; i < 50; i++) {
            sumaPerimetrosTriangulos +=triangulos[i].calcularPerimetro();
        }

        System.out.println("La suma de todas las areas de los triangulos es: "+
                sumaAreasTriangulos);
        System.out.println("La media de todas las areas de los triangulos es: "+
                (sumaAreasTriangulos/50));
        System.out.println("La suma de todos los perimetros de los triangulos es: "+
                sumaPerimetrosTriangulos);


        // ARRAY LIST//

        ArrayList<Rectangulo> listaRectangulos = new ArrayList<>(50);
        ArrayList<Circulo> listaCirculos = new ArrayList<>(50);
        ArrayList<Triangulo> listaTriangulos = new ArrayList<>(50);

        double min2 = 1;
        double max2 = 10;

        for (int i = 0; i < 50; i++) {
            double lado1 = rand.nextDouble(max2 - min2 +1)+ min2;
            double lado2 = rand.nextDouble(max2 - min2 +1)+ min2;
            listaRectangulos.add(new Rectangulo(lado1,lado2));
        }

        for (int i = 0; i < 50; i++) {
            double radio = rand.nextDouble(max2 - min2 +1)+ min2;
            listaCirculos.add(new Circulo(radio));
        }

        for (int i = 0; i < 50; i++) {
            double altura = rand.nextDouble(max2 - min2 +1)+ min2;
            double base = rand.nextDouble(max2 - min2 +1)+ min2;
            listaTriangulos.add(new Triangulo(altura,base));
        }


        for (int i = 0; i < 50; i++) {
            System.out.println("Para un rectangulo de lados "+listaRectangulos.get(i).getLado2()+" y "+
                    listaRectangulos.get(i).getLado2()+ " el area seria "+ listaRectangulos.get(i).calcularArea()+
                    " y el perimetro "+ listaRectangulos.get(i).calcularPerimetro());
        }

        for (int i = 0; i < 50; i++) {
            System.out.println("Para un circulo de radio "+listaCirculos.get(i).getRadio()+
                    " el area seria "+ listaCirculos.get(i).calcularArea()+
                    " y el perimetro "+ listaCirculos.get(i).calcularPerimetro());
        }

        for (int i = 0; i < 50; i++) {
            System.out.println("Para un triangulo de base "+listaTriangulos.get(i).getBase()+" y altura "+
                    listaTriangulos.get(i).getAltura()+ " el area seria "+ listaTriangulos.get(i).calcularArea()+
                    " y el perimetro "+ listaTriangulos.get(i).calcularPerimetro());
        }



        double sumaPerimetrosRectangulos1 =0;
        double sumaAreasRectangulos1 =0;

        for (int i = 0; i < 50; i++) {
            sumaAreasRectangulos1 +=listaRectangulos.get(i).calcularArea();
        }
        for (int i = 0; i < 50; i++) {
            sumaPerimetrosRectangulos1 +=listaRectangulos.get(i).calcularPerimetro();
        }

        System.out.println("La suma de todas las areas de los rectangulos es: "+
                sumaAreasRectangulos1);
        System.out.println("La media de todas las areas de los rectangulos es: "+
                (sumaAreasRectangulos1 /50));
        System.out.println("La suma de todos los perimetros de los rectangulos es: "+
                sumaPerimetrosRectangulos1);

        double sumaPerimetrosCirculos1 =0;
        double sumaAreasCirculos1 =0;

        for (int i = 0; i < 50; i++) {
            sumaAreasCirculos1 +=listaCirculos.get(i).calcularArea();
        }
        for (int i = 0; i < 50; i++) {
            sumaPerimetrosCirculos1 +=listaCirculos.get(i).calcularPerimetro();
        }

        System.out.println("La suma de todas las areas de los circulos es: "+
                sumaAreasCirculos1);
        System.out.println("La media de todas las areas de los circulos es: "+
                (sumaAreasCirculos1 /50));
        System.out.println("La suma de todos los perimetros de los circulos es: "+
                sumaPerimetrosCirculos1);


        double sumaPerimetrosTriangulos1 =0;
        double sumaAreasTriangulos1 =0;

        for (int i = 0; i < 50; i++) {
            sumaAreasTriangulos1 +=listaTriangulos.get(i).calcularArea();
        }
        for (int i = 0; i < 50; i++) {
            sumaPerimetrosTriangulos1 +=listaTriangulos.get(i).calcularPerimetro();
        }

        System.out.println("La suma de todas las areas de los triangulos es: "+
                sumaAreasTriangulos1);
        System.out.println("La media de todas las areas de los triangulos es: "+
                (sumaAreasTriangulos1 /50));
        System.out.println("La suma de todos los perimetros de los triangulos es: "+
                sumaPerimetrosTriangulos1);
    }
}