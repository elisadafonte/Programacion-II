

import java.util.Random;
public class Main {
    public static void main(String[] args) {

        try{
            Matriz matriz1 = new Matriz(3,3);
            Matriz matriz2 = new Matriz(3,3);
            Matriz matriz3 = new Matriz(5,5);
            Matriz matrizCero = new Matriz();

            Random rand = new Random();
            double max =5;
            double min =0;

            //Para que asigne valores random a la matriz,
            // basicamente porque no me vienen tantos numeros a la cabeza.
            for (int i = 0; i < matriz1.getFilas(); i++) {
                for (int j = 0; j < matriz1.getColumnas(); j++) {
                    double numero = (rand.nextDouble(max - min + 1) + min)*10;
                    double numDosDecimales = Math.round(numero)/10;
                    matriz1.setValor(i,j,numDosDecimales);
                }
            }
            for (int i = 0; i < matriz2.getFilas(); i++) {
                for (int j = 0; j < matriz2.getColumnas(); j++) {
                    double numero = (rand.nextDouble(max - min + 1) + min)*10;
                    double numDosDecimales = Math.round(numero)/10;
                    matriz2.setValor(i,j,numDosDecimales);
                }
            }
            for (int i = 0; i < matriz3.getFilas(); i++) {
                for (int j = 0; j < matriz3.getColumnas(); j++) {
                    double numero = (rand.nextDouble(max - min + 1) + min)*10;
                    double numDosDecimales = Math.round(numero)/10;
                    matriz3.setValor(i,j,numDosDecimales);
                }
            }

            System.out.println("A = " + "\n"+ matriz1+"\n");
            System.out.println("B = " + "\n"+ matriz2+"\n");
            System.out.println("C = " + "\n"+ matriz3+"\n");
            System.out.println("D = " + "\n"+ matrizCero+"\n");

            Matriz matrizSuma = matriz1.sumar(matriz2);
            System.out.println("A+B = " + "\n"+ matrizSuma+"\n");

            matriz2.multiplicarFila(2,2);
            System.out.println("2 * B = " + "\n"+ matriz2+"\n");

            Matriz matrizMultiplicada = matriz1.multiplicar(matriz2);
            System.out.println("A*B = " + "\n"+ matrizMultiplicada +"\n");

            Matriz matrizExtraida = matriz3.extraer(1,0,2,2);
            System.out.println("E (Extraida C) = " + "\n"+ matrizExtraida +"\n");

            Matriz matrizTraspuesta=matriz2.trasponer();
            System.out.println("F (Traspuesta B) = " + "\n"+ matrizTraspuesta+"\n");


            Matriz A = new Matriz(3, 3);
            A.setValor(0, 0, 1);
            A.setValor(0, 1, 0);
            A.setValor(0, 2, 1);
            A.setValor(1, 0, 0);
            A.setValor(1, 1, 2);
            A.setValor(1, 2, 1);
            A.setValor(2, 0, 1);
            A.setValor(2, 1, 5);
            A.setValor(2, 2, 4);

            System.out.println("Matriz original A:");
            System.out.println(A);

            int n = 3;
            Matriz extendida = new Matriz(6, 3); //


            for (int i = 0; i < n; i++) {
                for (int j = 0; j < n; j++) {
                    extendida.setValor(i, j, A.getValor(i, j));
                }
                for (int j = 0; j < n; j++) {
                    extendida.setValor(i, j + n, (i == j) ? 1.0 : 0.0);
                }
            }

            // Gauss-Jordan
            for (int i = 0; i < n; i++) {
                double pivote = extendida.getValor(i, i);
                if (pivote == 0.0) {
                    System.out.println("La matriz no es invertible.");
                    return;
                }

                // Normalizar fila i
                for (int j = 0; j < 2 * n; j++) {
                    double valor = extendida.getValor(i, j) / pivote;
                    extendida.setValor(i, j, valor);
                }

                // Hacer ceros en otras filas
                for (int k = 0; k < n; k++) {
                    if (k != i) {
                        double factor = extendida.getValor(k, i);
                        for (int j = 0; j < 2 * n; j++) {
                            double valor = extendida.getValor(k, j) - factor * extendida.getValor(i, j);
                            extendida.setValor(k, j, valor);
                        }
                    }
                }
            }

            // Extraer la parte derecha como inversa
            Matriz inversa = new Matriz(3, 3);
            for (int i = 0; i < n; i++) {
                for (int j = 0; j < n; j++) {
                    inversa.setValor(i, j, extendida.getValor(i, j + n));
                }
            }

            System.out.println("Matriz inversa de A:");
            System.out.println(inversa);


        } catch (Exception e) {
            System.out.println("ERROR");
        }

    }
}