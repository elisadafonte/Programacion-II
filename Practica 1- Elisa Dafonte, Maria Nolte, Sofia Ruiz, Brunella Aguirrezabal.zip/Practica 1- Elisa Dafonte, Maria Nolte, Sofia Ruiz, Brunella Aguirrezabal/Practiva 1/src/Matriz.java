import java.util.Arrays;

public class Matriz {
    double[][] matriz;
    int filas;
    int columnas;

    public Matriz(int columnas, int filas) {
        setColumnas(columnas);
        setFilas(filas);
        matriz = new double[filas][columnas];
        for (int i = 0; i < this.filas; i++) {
            for (int j = 0; j < this.columnas; j++) {
                matriz[i][j]=0;
            }
        }
    }

    public Matriz() {
        this.columnas=3;
        this.filas=3;
        matriz = new double[this.filas][this.columnas];
        for (int i = 0; i < this.filas; i++) {
            for (int j = 0; j < this.columnas; j++) {
                matriz[i][j]=0;
            }
        }
    }

    public double getValor (int fila, int columna){
        return matriz[fila][columna];
    }

    public void setValor (int fila, int columna, double valor){
        matriz[fila][columna] = valor;
    }

    public int getFilas() {
        return filas;
    }

    public void setFilas(int filas) {
        this.filas = filas;
    }

    public int getColumnas() {
        return columnas;
    }

    public void setColumnas(int columnas) {
        this.columnas = columnas;
    }

    public Matriz sumar (Matriz matriz2) throws Exception {
        if (this.filas != matriz2.filas || this.columnas!=matriz2.columnas){
            throw new Exception ("Suma: Las matrices no tienen el mismo tamaño");
        }
        else {
            Matriz matrizSolucion = new Matriz(this.columnas, this.filas);
            for (int i = 0; i < this.filas; i++) {
                for (int j = 0; j < this.columnas; j++) {
                    matrizSolucion.setValor(i,j,(this.getValor(i,j)+matriz2.getValor(i,j)));
                }
            }
            return matrizSolucion;
        }
    }

    public void multiplicarFila(int fila, int valor){
        for (int i = 0; i < this.columnas; i++) {
            setValor(fila, i, (getValor(fila,i)*valor));
        }
    }

    public Matriz multiplicar(Matriz matriz2) throws Exception {
        if (this.columnas != matriz2.filas) {
            throw new Exception("Las dimensiones no permiten multiplicación");
        }

        int filasResultado = this.filas;
        int columnasResultado = matriz2.columnas;
        int comun = this.columnas;

        Matriz resultado = new Matriz(filasResultado, columnasResultado);

        for (int i = 0; i < filasResultado; i++) {
            for (int j = 0; j < columnasResultado; j++) {
                double suma = 0;
                for (int k = 0; k < comun; k++) {
                    suma += this.getValor(i, k) * matriz2.getValor(k, j);
                }
                resultado.setValor(i, j, suma);
            }
        }
        return resultado;
    }

    public Matriz extraer(int filaInicial, int columnaInicial, int numFilas, int numColumnas) throws Exception {
            Matriz matrizExtraida = new Matriz(numColumnas, numFilas);
            int a =filaInicial;
            int b=columnaInicial;
            for (int i = 0; i < (numFilas) ; i++) {
                for (int j = 0; j <(numColumnas) ; j++) {
                    matrizExtraida.setValor(i,j,getValor(a,b));
                    b++;
                }
                a++;
            }
            return matrizExtraida;
    }

    public Matriz trasponer(){
        Matriz matrizTranspuesta = new Matriz(this.filas, this.columnas);

        for (int i = 0; i < this.filas; i++) {
            for (int j = 0; j < this.columnas; j++) {
                matrizTranspuesta.setValor(j,i,getValor(i,j));
            }
        }
        return matrizTranspuesta;
    }

    @Override
    public String toString() {
        String resultado="";
        for (int i = 0; i < this.filas; i++) {
            for (int j = 0; j < this.columnas; j++) {
                resultado += getValor(i,j) +"  ";
            }
            resultado += '\n';
        }
        return resultado;
    }
}
