//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {

        final double PI = 3.1415926536;
        double diametro = 15.5;
        double altura = 42.4;
        double radio = diametro/2;
        double generatriz = (Math.sqrt((radio*radio)+(altura*altura)));
        double area1 = (PI * (radio*radio));
        double area2 =(PI*radio*generatriz);
        double area = area1+area2;
        double volumen = (PI*altura*radio*radio)/3;
        System.out.println("Sabiendo que el diametro del cono es " + diametro
                + " y la altura " + altura + ", podemos determinar que la " +
                "generatriz es "+ generatriz+ ", el area es "
                + area + " y el volumen " + volumen);
   }
}