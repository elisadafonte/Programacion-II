import java.io.*;
import java.time.LocalDate;
import java.util.ArrayList;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {

        try{
            Supermercado dia = new Supermercado("dia");

            dia.comprarProducto((Producto)(new ProductoPerecedero("Manzanas", "Manzanas de Valencia.",TipoMedida.KILOGRAMOS,LocalDate.now().plusDays(10))),1000, LocalDate.now(),2.5);
            dia.comprarProducto((Producto)(new ProductoPerecedero("Peras", "Peras de Sevilla.",TipoMedida.KILOGRAMOS,LocalDate.now().plusDays(10))),500, LocalDate.now(),1.5);

            dia.comprarProducto((Producto)(new ProductoNoPerecedero("Papel Higienico", "Papel Higienico de doble capa.",TipoMedida.UNIDADES)),300, LocalDate.now(),3.5);
            dia.comprarProducto((Producto)(new ProductoNoPerecedero("Champu", "Champu con olor a rosas.",TipoMedida.UNIDADES)),200, LocalDate.now(),4.5);

            dia.ventaProducto((Producto)(new ProductoPerecedero("Manzanas", "Manzanas de Valencia.",TipoMedida.KILOGRAMOS,LocalDate.now().plusDays(10))),50,LocalDate.of(2023,6,26),3.10);
            dia.ventaProducto((Producto)(new ProductoPerecedero("Peras", "Peras de Sevilla.",TipoMedida.KILOGRAMOS,LocalDate.now().plusDays(10))),50,LocalDate.of(2023,6,26),2.20);

            dia.ventaProducto((Producto)(new ProductoNoPerecedero("Champu", "Champu con olor a rosas.",TipoMedida.UNIDADES)),2,LocalDate.of(2023,6,26),6.1);

            ArrayList<Operacion> operacionesCaducadas = dia.proximaCaducidad(15);

            if (operacionesCaducadas.isEmpty()){
                System.out.println("No hay productos que caduquen en los proximos 15 dias.");
            }
            else{
                for (int i = 0; i < operacionesCaducadas.size(); i++) {
                    ProductoPerecedero producto1 = (ProductoPerecedero) operacionesCaducadas.get(i).getProducto();
                    System.out.println(producto1.getNombre() +
                    "   " + operacionesCaducadas.get(i).getCantidad() + producto1.getMedida()+
                    "    Cad: "+ producto1.getFechaCaducidad() +
                    "    Valor: "+ (operacionesCaducadas.get(i).getCantidad()*operacionesCaducadas.get(i).getPrecio())+"€");
                }
            }

            String archivoBinario = "supermercado.sup";
            String archivoTxt = "Operaciones_supermecado.txt";

            try{
                FileOutputStream fos = new FileOutputStream(archivoBinario);
                ObjectOutputStream oos = new ObjectOutputStream(fos);
                oos.writeObject(dia);
                oos.close();
            }  catch (IOException e) {
                System.out.println("Error al guardar: "+ e.getMessage());
            }

            Supermercado superLeido= null;
            try{
                FileInputStream fis = new FileInputStream(archivoBinario);
                ObjectInputStream ois = new ObjectInputStream(fis);
                superLeido = (Supermercado)ois.readObject();
                ois.close();
            } catch (ClassNotFoundException e) {
                System.out.println("Clase no encontrada. ");
            } catch (IOException e) {
                System.out.println("Error al leer: "+ e.getMessage());
            }


            if (superLeido !=null){
                System.out.println("Productos perecederos: ");
                for (int i = 0; i < superLeido.getAlmacen().size(); i++) {
                    if (superLeido.getAlmacen().get(i).getProducto() instanceof ProductoPerecedero){
                        System.out.println(superLeido.getAlmacen().get(i).getOperacion() +
                        "   "+superLeido.getAlmacen().get(i).getProducto().getNombre()
                        + "    " + superLeido.getAlmacen().get(i).getCantidad() + superLeido.getAlmacen().get(i).getProducto().getMedida()
                        + "  a  " + superLeido.getAlmacen().get(i).getPrecio()+ "€/" +superLeido.getAlmacen().get(i).getProducto().getMedida());
                        System.out.println("           Fecha: "+ superLeido.getAlmacen().get(i).getFecha() +
                                "    Caducidad: "+ ((ProductoPerecedero) superLeido.getAlmacen().get(i).getProducto()).getFechaCaducidad());
                    }
                }
                System.out.println("\nProductos no perecederos: ");
                for (int i = 0; i < superLeido.getAlmacen().size(); i++) {
                    if (superLeido.getAlmacen().get(i).getProducto() instanceof ProductoNoPerecedero){
                        System.out.println(superLeido.getAlmacen().get(i).getOperacion() +
                                "   "+superLeido.getAlmacen().get(i).getProducto().getNombre()
                                + "    " + superLeido.getAlmacen().get(i).getCantidad() + superLeido.getAlmacen().get(i).getProducto().getMedida()
                                + "  a  " + superLeido.getAlmacen().get(i).getPrecio()+ "€/" +superLeido.getAlmacen().get(i).getProducto().getMedida());
                        System.out.println("           Fecha: "+ superLeido.getAlmacen().get(i).getFecha());
                    }
                }
            }

            try{
                PrintWriter pw = new PrintWriter(archivoTxt);
                pw.println("Productos perecederos: ");
                for (int i = 0; i < superLeido.getAlmacen().size(); i++) {
                    if (superLeido.getAlmacen().get(i).getProducto() instanceof ProductoPerecedero){
                        pw.println(superLeido.getAlmacen().get(i).getOperacion() +
                                "   "+superLeido.getAlmacen().get(i).getProducto().getNombre()
                                + "    " + superLeido.getAlmacen().get(i).getCantidad() + superLeido.getAlmacen().get(i).getProducto().getMedida()
                                + "  a  " + superLeido.getAlmacen().get(i).getPrecio()+ "€/" +superLeido.getAlmacen().get(i).getProducto().getMedida());
                        pw.println("           Fecha: "+ superLeido.getAlmacen().get(i).getFecha() +
                                "    Caducidad: "+ ((ProductoPerecedero) superLeido.getAlmacen().get(i).getProducto()).getFechaCaducidad());
                    }
                }
                pw.println("\nProductos no perecederos: ");
                for (int i = 0; i < superLeido.getAlmacen().size(); i++) {
                    if (superLeido.getAlmacen().get(i).getProducto() instanceof ProductoNoPerecedero){
                        pw.println(superLeido.getAlmacen().get(i).getOperacion() +
                                "   "+superLeido.getAlmacen().get(i).getProducto().getNombre()
                                + "    " + superLeido.getAlmacen().get(i).getCantidad() + superLeido.getAlmacen().get(i).getProducto().getMedida()
                                + "  a  " + superLeido.getAlmacen().get(i).getPrecio()+ "€/" +superLeido.getAlmacen().get(i).getProducto().getMedida());
                        pw.println("           Fecha: "+ superLeido.getAlmacen().get(i).getFecha());
                    }
                }
                pw.close();
            } catch (FileNotFoundException e) {
                System.out.println("No se pudo crear el archivo de texto.");;
            }

        } catch (OperacionNoValidaException e) {
            throw new RuntimeException(e);
        }
    }
}