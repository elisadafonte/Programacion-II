import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;

public class Supermercado implements Serializable {
    private String nombre;
    private ArrayList<Operacion> almacen;


    //CONSTRUCTOR, NOS SOLICITA UN DATO (EL NOMBRE) Y CON ELLO LLAMA A LA FUNCION SET Y TAMBIEN CREA EL ARRAYLIST DE ALMACEN
    public Supermercado(String nombre) {
        setNombre(nombre);
        almacen = new ArrayList<>();
    }


    //NOS SIRVE PARA DARLE UN VALOR A LA VARIABLE NOMBRE
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }


    //NOS DA LA INFORMACION DENTRO DEL "ALMACEN"
    public ArrayList<Operacion> getAlmacen() {
        return almacen;
    }


    //SOLITITA UN PRODUCTO, UNA CANTIDAD, UNA FECHA Y UN PRECIO Y CREA UNA NUEVA TRANSACCION
    public boolean comprarProducto (Producto producto, int cantidad, LocalDate fecha, double precio) throws OperacionNoValidaException {
        if (producto instanceof ProductoPerecedero){
            if (((ProductoPerecedero) producto).getFechaCaducidad().isAfter(fecha)){
                almacen.add(new Operacion (TipoOperacion.COMPRA,producto,cantidad,fecha,precio));
                return true;
            }
            else {
                return false;
            }
        }
        else{
            almacen.add(new Operacion (TipoOperacion.COMPRA,producto,cantidad,fecha,precio));
            return true;
        }
    }


    //LO MISMO QUE COMPRA PERO HACIENDO UNA VENTA Y NO UNA COMPRA.
    public boolean ventaProducto (Producto producto, int cantidad, LocalDate fecha, double precio) throws OperacionNoValidaException {
        int cantidadAlmacen = cantidadProducto(producto);
        if (cantidad<=cantidadAlmacen){
            almacen.add(new Operacion (TipoOperacion.VENTA,producto,cantidad,fecha,precio));
            return true;
        }
        else{
            return false;
        }
    }


    //PARA DARNOS A CONOCER EL NUMERO DE PRODUCTOS QUE TENEMOS EN EL ALMACEN DE UN TIPO ESPECIFICO.
    public int cantidadProducto(Producto producto){
        int sumaCompras = 0;
        int sumaVentas = 0;
        for (int i = 0; i < almacen.size(); i++) {
            if (almacen.get(i).getProducto()==producto){
                if (almacen.get(i).getOperacion()==TipoOperacion.COMPRA){
                    sumaCompras += almacen.get(i).getCantidad();
                }
                if (almacen.get(i).getOperacion()==TipoOperacion.VENTA){
                    sumaVentas += almacen.get(i).getCantidad();
                }
            }
        }
        return (sumaCompras-sumaVentas);
    }


    //PARA TENER UNA LISTA DE LAS OPERACIONES HECHAS DE PRODUCTOS QUE CADUCAN EN X DIAS
    public ArrayList<Operacion> proximaCaducidad(int numDias) {
        ArrayList<Operacion> operacionesCaducados = new ArrayList<>();
        LocalDate hoy = LocalDate.now();
        for (int i = 0; i < almacen.size(); i++) {
            if (almacen.get(i).getProducto() instanceof ProductoPerecedero){

                if ((((ProductoPerecedero) almacen.get(i).getProducto()).getFechaCaducidad().isBefore(hoy.plusDays(numDias))
                && ((ProductoPerecedero) almacen.get(i).getProducto()).getFechaCaducidad().isAfter(hoy)) ||
                ((ProductoPerecedero) almacen.get(i).getProducto()).getFechaCaducidad().isEqual(hoy)
                ||((ProductoPerecedero) almacen.get(i).getProducto()).getFechaCaducidad().isEqual(hoy.plusDays(numDias))){

                    operacionesCaducados.add(almacen.get(i));
                }
            }
        }
        return operacionesCaducados;
    }
}
