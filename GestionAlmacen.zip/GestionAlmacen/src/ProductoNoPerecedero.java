import java.io.Serializable;

public class ProductoNoPerecedero extends Producto implements Serializable {

    public ProductoNoPerecedero(String nombre, String descripcion, TipoMedida medida) {
        super(nombre, descripcion, medida);
    }
}
