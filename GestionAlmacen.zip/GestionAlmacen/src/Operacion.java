import java.io.Serializable;
import java.time.LocalDate;

public class Operacion implements Serializable {
    private TipoOperacion operacion;
    private Producto producto;
    private double cantidad;
    private LocalDate fecha;
    private double precio;

    public Operacion(TipoOperacion operacion, Producto producto, double cantidad, LocalDate fecha, double precio) throws OperacionNoValidaException {
        if (cantidad<=0||fecha.isAfter(LocalDate.of(2028,1,1))
        ||fecha.isBefore(LocalDate.of(1900, 1, 1))||
        precio<=0||precio>500){
            throw new OperacionNoValidaException("Datos no validos para la operacion.");
        }

        setOperacion(operacion);
        setProducto(producto);
        setCantidad(cantidad);
        setFecha(fecha);
        setPrecio(precio);
    }

    public TipoOperacion getOperacion() {
        return operacion;
    }

    public void setOperacion(TipoOperacion operacion) {
        this.operacion = operacion;
    }

    public Producto getProducto() {
        return producto;
    }

    public void setProducto(Producto producto) {

        this.producto = producto;
    }

    public double getCantidad() {
        return cantidad;
    }

    public void setCantidad(double cantidad) {
        this.cantidad = cantidad;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }
}
