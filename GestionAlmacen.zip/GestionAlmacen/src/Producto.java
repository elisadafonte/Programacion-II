import java.io.Serializable;

abstract class Producto implements Serializable {
    private String nombre;
    private String descripcion;
    private TipoMedida medida;

    public Producto(String nombre, String descripcion, TipoMedida medida) {
        setNombre(nombre);
        setDescripcion(descripcion);
        setMedida(medida);
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public TipoMedida getMedida() {
        return medida;
    }

    public void setMedida(TipoMedida medida) {
        this.medida = medida;
    }
}
