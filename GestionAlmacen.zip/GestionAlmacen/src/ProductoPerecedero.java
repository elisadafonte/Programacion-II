import java.io.Serializable;
import java.time.LocalDate;

public class ProductoPerecedero extends Producto implements Serializable {
    private LocalDate fechaCaducidad;


    public ProductoPerecedero(String nombre, String descripcion, TipoMedida medida, LocalDate fechaCaducidad) {
        super(nombre, descripcion, medida);
        setFechaCaducidad(fechaCaducidad);
    }

    public LocalDate getFechaCaducidad() {
        return fechaCaducidad;
    }

    public void setFechaCaducidad(LocalDate fechaCaducidad) {
        this.fechaCaducidad = fechaCaducidad;
    }
}
