//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
import java.util.Scanner;
public class Main {
    public static void main(String[] args) {

        Scanner teclado = new Scanner(System.in);

        System.out.println("-- BIENVENIDO A NUESTRO PROGRAMA --");
        System.out.println("En este programa vamos a solicitar dos numeros enteros de tu elección y vamos a hacer diferentes operaciones con ellos.");

        int ent1;
        int ent2;

        System.out.print("Ingrese el primer numero entero: ");
        ent1 = teclado.nextInt();

        System.out.print("Ingrese el segundo numero entero: ");
        ent2 = teclado.nextInt();

        System.out.println("Los numeros ingeresados son: " + ent1 + " y " + ent2);

        int suma = ent1 + ent2;
        System.out.println("La suma de " + ent1 + " y " + ent2 + " es " + suma);
        if (suma < 0 ){
            System.out.println("El resultado de la operación es negativo.");
        }

        int diferencia = ent1 - ent2;
        System.out.println("La diferencia entre " + ent1 + " y " + ent2 + " es " + diferencia);
        if (diferencia < 0 ){
            System.out.println("El resultado de la operación es negativo.");
        }

        int producto = ent1*ent2;
        System.out.println("El producto de " + ent1 + " y " + ent2 + " es " + producto);
        if (producto < 0 ){
            System.out.println("El resultado de la operación es negativo.");
        }

        int division =ent1/ent2;
        System.out.println("La division de " + ent1 + " entre " + ent2 + " es " + division);
        if (division < 0 ){
            System.out.println("El resultado de la operación es negativo.");
        }

        int modulo = ent1%ent2;
        System.out.println("El modulo de " + ent1 + " y " + ent2 + " es " + modulo);
        if (modulo < 0 ){
            System.out.println("El resultado de la operación es negativo.");
        }

        System.out.println("-- GRACIAS A NUESTRO PROGRAMA --");

    }
}