//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {

        int base = 15;
        int altura = 25;

        int perimetro = (base *2) + (altura*2);
        int area = base*altura;

        System.out.println("Sabiendo que la base del rectangulo mide " + base
                + " y la altura " + altura + ", podemos determinar que el perimetro es "
                + perimetro + " y el area " + area);
    }
}