//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {

        Producto producto1;
        Producto producto2;
        Producto producto3;

        producto1= new Producto("Patatas", "Patatas con sabor jamon",
                "Ruffles", 1.50, 1.95,5678);

        producto2 = new Producto("Boligrafo", "Boligrafo de tinta azul y punta 0.7", "BIC");

        producto3 = new Producto("Fideos Instantaneos", "Fideos instantaneos con sabor pollo",
                "Yatekomo", 2.3, 2.99, 1728);

        System.out.println(producto1);
        System.out.println(producto2);
        System.out.println(producto3);

        producto1.comprar(500, 1.8);
        System.out.println("Se han comprado 500 unidades al precio de 1.8");
        System.out.println(producto1);


        System.out.println("Se ha vendido la cantidad propuesta por el precio de: "+ producto3.vender(30000));
        System.out.println(producto3);

        System.out.println("Se ha vendido la cantidad propuesta por el precio de: "+ producto1.vender(50));
        System.out.println(producto1);
        
    }
}