import javax.swing.event.MenuDragMouseListener;

public class Producto {
    String nombre;
    String descripcion;
    String marca;
    Double precioCompra;
    Double precioVenta;
    int cantidadAlmacen;

    public Producto(String nombre, String descripcion, String marca, Double precioCompra, Double precioVenta, int cantidadAlmacen) {
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.marca = marca;
        this.precioCompra = precioCompra;
        this.precioVenta = precioVenta;
        this.cantidadAlmacen = cantidadAlmacen;
    }

    public Producto(String nombre, String descripcion, String marca) {
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.marca = marca;
    }

    public String getNombre() {
        return nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public String getMarca() {
        return marca;
    }

    public Double getPrecioCompra() {
        return precioCompra;
    }

    public Double getPrecioVenta() {
        return precioVenta;
    }

    public int getCantidadAlmacen() {
        return cantidadAlmacen;
    }

    public void comprar (int cantidadComprada, Double precioNuevo){
        this.cantidadAlmacen += cantidadComprada;
        this.precioCompra = precioNuevo;
        this.precioVenta = precioNuevo + (precioNuevo*0.3);
    }

    public Double vender (int cantidadVendida){
        if (cantidadVendida<this.cantidadAlmacen){
            this.cantidadAlmacen = this.cantidadAlmacen-cantidadVendida;
            return this.precioVenta*cantidadVendida;
        }
        else{return (double) 0;}
    }

    @Override
    public String toString() {
        if (this.precioCompra != null) {
            return "\n" + "Producto" + "\n" +
                    "Nombre: " + nombre + "\n" +
                    "Descripcion: " + descripcion + "\n" +
                    "Marca: " + marca + "\n" +
                    "Precio de Compra: " + precioCompra + "\n" +
                    "Precio de Venta: " + precioVenta + "\n" +
                    "Cantidad en el Almacen: " + cantidadAlmacen + "\n"
                    ;
        }
        else{
            return "\n" + "Producto" + "\n" +
                    "Nombre: " + nombre + "\n" +
                    "Descripcion: " + descripcion + "\n" +
                    "Marca: " + marca + "\n";
        }
    }

}

