import java.time.LocalDate;

public class Contrato {
    private String puesto;
    private double salarioBase;
    private LocalDate fechaAlta;
    private LocalDate fechaBaja;
    private Complementos suma;
    private Deducciones resta;


    public Contrato(String puesto, double salarioBase, LocalDate fechaAlta) {
        this.puesto = puesto;
        this.salarioBase = salarioBase;
        this.fechaAlta = fechaAlta;
        this.fechaBaja = null;
    }

    public Contrato(String puesto, double salarioBase, LocalDate fechaAlta, LocalDate fechaBaja) {
        this.puesto = puesto;
        this.salarioBase = salarioBase;
        this.fechaAlta = fechaAlta;
        this.fechaBaja = fechaBaja;
    }

    public String getPuesto() {
        return puesto;
    }

    public void setPuesto(String puesto) {
        this.puesto = puesto;
    }

    public double getSalarioBase() {
        return salarioBase;
    }

    public void setSalarioBase(double salarioBase) {
        this.salarioBase = salarioBase;
    }

    public LocalDate getFechaAlta() {
        return fechaAlta;
    }

    public void setFechaAlta(LocalDate fechaAlta) {
        this.fechaAlta = fechaAlta;
    }

    public LocalDate getFechaBaja() {
        return fechaBaja;
    }

    public void setFechaBaja(LocalDate fechaBaja) {
        this.fechaBaja = fechaBaja;
    }

    public Complementos getSuma() {
        return suma;
    }

    public void setSuma(Complementos suma) {
        this.suma = suma;
    }

    public Deducciones getResta() {
        return resta;
    }

    public void setResta(Deducciones resta) {
        this.resta = resta;
    }


    public void agregarComplemento(HoraExtra horaExtra){
        suma.agregarHoraExtra(horaExtra);

    }

    public void modificarComplemento(HoraExtra horaExtra){

    }

    public boolean estaDeBaja(){
        return fechaBaja != null;

    }

}
