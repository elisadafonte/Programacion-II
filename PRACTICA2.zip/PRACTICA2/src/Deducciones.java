import java.util.ArrayList;

public class Deducciones {
    private double irpf;
    private ArrayList<DiaBaja> periodoBaja;

    public Deducciones(double irpf) {
        this.irpf = irpf;
        this.periodoBaja = new ArrayList<>();
    }

    public double getIrpf() {
        return irpf;
    }

    public void setIrpf(double irpf) {
        this.irpf = irpf;
    }

    public ArrayList<DiaBaja> getPeriodoBaja() {
        return periodoBaja;
    }

    public void setPeriodoBaja(ArrayList<DiaBaja> periodoBaja) {
        this.periodoBaja = periodoBaja;
    }
}


