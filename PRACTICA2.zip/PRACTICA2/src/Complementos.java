import java.util.ArrayList;

public class Complementos {
    private int trienios;
    private ArrayList<HoraExtra> horaExtra;

    public Complementos(int trienios) {
        this.trienios = trienios;
        this.horaExtra=  new ArrayList<>();
    }

    public int getTrienios() {
        return trienios;
    }

    public void setTrienios(int trienios) {
        this.trienios = trienios;
    }

    public ArrayList<HoraExtra> getHoraExtra() {
        return horaExtra;
    }

    public void setHoraExtra(ArrayList<HoraExtra> horaExtra) {
        this.horaExtra = horaExtra;
    }

    public void agregarHoraExtra(HoraExtra horaExtra){
        this.horaExtra.add(horaExtra);

    }
    public void modificarHoraExtra(HoraExtra horaExtra){


    }


}
