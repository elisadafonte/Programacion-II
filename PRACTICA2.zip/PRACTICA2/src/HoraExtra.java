public class HoraExtra {
    private int numero;
    private int mes;
    private int anio;


    public HoraExtra(int numero, int mes, int anio) {
        this.numero = numero;
        this.mes = mes;
        this.anio = anio;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public int getMes() {
        return mes;
    }

    public void setMes(int mes) {
        this.mes = mes;
    }

    public int getAnio() {
        return anio;
    }

    public void setAnio(int anio) {
        this.anio = anio;
    }
}
