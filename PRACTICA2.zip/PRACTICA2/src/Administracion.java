import java.time.LocalDate;

public class Administracion extends Persona{
    public Administracion(String nombre, String telefono, LocalDate fechaNacimiento, String dni, CuentaBancaria cuentaBancaria) {
        super(nombre, telefono, fechaNacimiento, dni, cuentaBancaria);
    }

    @Override
    public String toString() {
        return  nombre + " Administracion " + contrato.getPuesto() + contrato.getFechaAlta().getDayOfMonth() + "/ " +
                + contrato.getFechaAlta().getMonthValue() +  "/"+  contrato.getFechaAlta().getYear();
    }
}
