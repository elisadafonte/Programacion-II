import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Scanner;

public class Main {
    private static ArrayList<Persona> empleados;
    private static Scanner teclado;

    public static void main(String[] args) {
        empleados = new ArrayList<>();
        Scanner teclado = new Scanner(System.in);
        int opcion = -1;

        while (opcion != 0) {
            opcion = mostrarMenu();
            switch (opcion) {
                case 0:
                    System.out.println("Cerrando el programa");
                    break;
                case 1:
                    darDeAltaTrabajador();
                    break;
                case 2:
                    darDeBajaTrabajador();
                    break;
                case 3:
                    agregarTecnico();
                    break;
                case 4:
                    quitarTecnico();
                    break;
                case 5:
                    anadirHorasExtra();
                    break;
                case 6:
                    listaEmpleadosActuales();

                    break;
                case 7:
                    listaEmpleadosBaja();
                    break;
                case 8:
                    listaEmpleadosAdministracion();
                    break;
                case 9:
                    break;
                case 10:
                    break;
                case 11:
                    break;

            }
        }


    }

    private static void listaEmpleadosAdministracion() {
        if (empleados.isEmpty()){
            System.out.println("No hay empleados registrados.");
        }
        else {
            System.out.println("Listado de empelados actuales: ");
            for (Persona p : empleados) {
                if (p.getContrato().estaDeBaja() == false && p instanceof Administracion) {

                    System.out.println(p.getNombre() + " " + p.getContrato().getPuesto());

                }

            }
        }
    }

    private static void listaEmpleadosBaja() {
        if (empleados.isEmpty()){
            System.out.println("No hay empleados registrados.");
        }
        else {
            System.out.println("Listado de empelados dados de baja: ");
            for (Persona p : empleados) {
                if (p.getContrato().estaDeBaja() ) {

                    System.out.println(p.toString() + p.getContrato().getFechaBaja());

                }

            }
        }
    }

    private static void listaEmpleadosActuales() {
        if (empleados.isEmpty()){
            System.out.println("No hay empleados registrados.");
        }
        else {
            System.out.println("Listado de empelados actuales: ");
            for (Persona p : empleados) {
                if (p.getContrato().estaDeBaja() == false) {

                    System.out.println(p.toString());

                }

            }
        }
    }

    private static void anadirHorasExtra() {
        System.out.println("Introduzca el dni: ");
        String dni= teclado.nextLine();
        Persona persona =buscarEmpleado(dni);
        if (persona == null){
            System.out.println("No existe una persona con ese dni");
        }
        else {

            int mes = pedirMes();
            int anio= pedirAnio(2020,2025);
            System.out.println("Introduzca el numero de horas extra: ");
            int numero= teclado.nextInt();
            HoraExtra horaExtra = new HoraExtra(numero,mes,anio);
            persona.getContrato().agregarComplemento(horaExtra);
            System.out.println("Registradas correctamnete las horas extra");


        }

    }


    private static void quitarTecnico() {
        System.out.println("Introduzca el nombre del equipo: ");
        String nombreEquipo = teclado.nextLine();
        System.out.println("Introduzca el dni del tecnico: ");
        String dni= teclado.nextLine();
        JefeDeGrupo jefeDeGrupo= buscarEquipo(nombreEquipo);
        if (jefeDeGrupo== null){
            System.out.println("No existe un equipo con ese nombre ");

        }
        else {
            Persona persona = buscarEmpleado(dni) ;
            if (persona == null){
                System.out.println("No existe ningun trabajador con ese dni");

            }
            else {
                if (persona instanceof Tecnico){
                    if (jefeDeGrupo.existeTecnico((Tecnico) persona)){
                        jefeDeGrupo.eliminarTecnico((Tecnico) persona);
                        System.out.println("Se ha elimiando el tecnico correctamente");
                    }
                    else{

                        System.out.println("Ese tecnico no pertenece a ese equipo");
                    }
                }
                else {
                    System.out.println("Ese dni no corresponde a un tecnico");
                }
            }
        }
    }

    private static void agregarTecnico() {

        System.out.println("Introduzca el nombre del equipo: ");
        String nombreEquipo = teclado.nextLine();
        System.out.println("Introduzca el dni del tecnico: ");
        String dni= teclado.nextLine();
        JefeDeGrupo jefeDeGrupo= buscarEquipo(nombreEquipo);
        if (jefeDeGrupo== null){
            System.out.println("No existe un equipo con ese nombre ");

        }
        else {
           Persona persona = buscarEmpleado(dni) ;
           if (persona == null){
               System.out.println("No existe ningun trabajador con ese dni");

           }
           else {
               if (persona instanceof Tecnico){
                   if (jefeDeGrupo.existeTecnico((Tecnico) persona)){
                       System.out.println("Ese tecnico ya pertenece a ese equipo");
                   }
                   else{
                       jefeDeGrupo.agregarTecnico((Tecnico) persona);
                       System.out.println("Se ha agregad el tecnico con exito");
                   }
               }
               else {
                   System.out.println("Ese dni no corresponde a un tecnico");
               }
           }
        }
    }

    private static JefeDeGrupo buscarEquipo(String nombreEquipo){
        for (Persona p: empleados){
            if (p instanceof JefeDeGrupo ){
                if (((JefeDeGrupo)p).getNombreEquipo().equalsIgnoreCase(nombreEquipo)){
                    return (JefeDeGrupo)p;

                }
            }
        }
        return null;



    }

    private static void darDeBajaTrabajador() {
        System.out.println("Introduzca el dni:");
        String dni = teclado.nextLine();
        Persona empleado = buscarEmpleado(dni);
        if (empleado == null) {
            System.out.println("El empleado no existe");
        } else {
            System.out.println("Introduzca la fecha de baja : ");
            LocalDate fechaBaja = pedirFecha();
            empleado.getContrato().setFechaBaja(fechaBaja);
        }
    }

    private static void darDeAltaTrabajador() {
        System.out.println("Introduzca el dni:");
        String dni = teclado.nextLine();
        if (buscarEmpleado(dni) != null) {
            System.out.println("El empleado ya existe");
        } else {
            System.out.println("Introduzca el nombre: ");
            String nombre= teclado.nextLine();
            System.out.println("Introduzca el numero de telefono");
            String telefono= teclado.nextLine();
            System.out.println("A continuacion introduzca la fecha de nacimiento.");
            LocalDate fechaNacimiento =pedirFecha();
            System.out.println("Introduzca el nombre de entidad: ");
            String nombreEntidad= teclado.nextLine();
            System.out.println("Introduzca el iban: ");
            String iban = teclado.nextLine();
            CuentaBancaria cuentaBancaria = new CuentaBancaria(nombreEntidad,iban) ;

            int tipoEmpleado = 0;
            Persona empleado = null;
            do {
                System.out.println("Indique el tipo de empleado(0.Tecnico, 1.Admistracion, 2.Jefe de Grupo)");
                tipoEmpleado = teclado.nextInt();

                switch (tipoEmpleado) {
                    case 0:
                        empleado = new Tecnico(nombre, telefono, fechaNacimiento, dni, cuentaBancaria);
                        break;
                    case 1:
                        empleado = new Administracion(nombre, telefono, fechaNacimiento, dni, cuentaBancaria);
                        break;
                    case 2:
                        System.out.println("Introduzca el nombre del equipo: ");
                        String nombreEquipo = teclado.nextLine();
                        empleado = new JefeDeGrupo(nombre, telefono, fechaNacimiento, dni, cuentaBancaria, nombreEquipo);
                        break;

                    default:
                        System.out.println("Opcion invalida");
                        break;

                }
            } while (tipoEmpleado<0 || tipoEmpleado>2);//ahora solicitar datos del contrato



            System.out.println("Introduzca el puesto: ");
            String puesto = teclado.nextLine();
            System.out.println("Introduzca el Salario Base: ");
            double salarioBase = teclado.nextDouble();
            System.out.println("A continuacion introduzca la fecha de Alta.");
            LocalDate fechaAlta = pedirFecha();
            System.out.println("Introuzca el IRPF:");
            double irpf = teclado.nextDouble();
            System.out.println("Introduzca el trienio: ");
            int trienio = teclado.nextInt();

            Complementos complementos = new Complementos(trienio);
            Deducciones deducciones = new Deducciones(irpf);
            Contrato contrato = new Contrato(puesto, salarioBase, fechaAlta);
            contrato.setSuma(complementos);
            contrato.setResta(deducciones);
            empleado.setContrato(contrato);
            empleados.add(empleado);
        }

    }

    private static int pedirMes(){
        int mes=0;
        boolean continuar = true;
        while (continuar) {
            System.out.println("Introduzca el mes: ");
            mes = teclado.nextInt();
            if (mes < 1 || mes > 12) {
                System.out.println("Mes invalido");
            } else {
                continuar = false;
            }
        }
        return mes;
    }

    private static int pedirAnio(int valorMin, int valorMax){
        int anio =0;
        boolean continuar = true;
        while (continuar) {
            System.out.println("Introduzca el anio: ");
            anio = teclado.nextInt();
            if (anio < valorMin || anio > valorMax) {
                System.out.println("Anio invalido");
            } else {
                continuar = false;
            }
        }
        return anio;
    }

    private static LocalDate pedirFecha(){
        boolean continuar = true;
        LocalDate localDate = null;
       do {

            int dia=0;
            int mes=0;
            int anio=0;

           while (continuar) {
               System.out.println("Introduzca el dia: ");
               dia = teclado.nextInt();
               if (dia < 1 || dia > 31) {
                   System.out.println("Dia invalido");
               } else {
                   continuar = false;
               }
           }
          mes=pedirMes();
          anio=pedirAnio(1900,2025);

           continuar=true;

           try {
               localDate = LocalDate.of(anio, mes, dia);
              continuar = false;


           } catch (Exception e) {
               System.out.println("Fecha invalida");
           }
       } while (continuar);
       return localDate;

    }


    private static Persona buscarEmpleado(String dni) {
        for (Persona p : empleados) {
            if (p.getDni().equalsIgnoreCase(dni)) {
                return p;
            }

        }
        return null;
    }

    private static int mostrarMenu() {
        int opcion = -1;
        do {
            System.out.println("------Gestor de nominas------");
            System.out.println("1.Dar de Alta un contrato");
            System.out.println("2.Dar de Baja un contrato");
            System.out.println("3.Añadir un tecnico al equipo");
            System.out.println("4.Quitar un tecnico del equipo");
            System.out.println("5.Añadir horas extra a un empleado ");
            System.out.println("6.Listado de los empelados activos");
            System.out.println("7.Listado de los empleados dados de baja ");
            System.out.println("8.Listado de empelados de administracion");
            System.out.println("9.Listado de equipos");
            System.out.println("10.Generar nomina de un empleado");
            System.out.println("11.Generar todas las nominas para un mes y año");
            System.out.println("0.Salir");
            System.out.println("Introduzca la opcion que desee: ");
            try {
                opcion = teclado.nextInt();
                if (opcion < 0 || opcion > 11) {
                    System.out.println("La opcion es invalida. ");
                }
            } catch (Exception e) {
                System.out.println("La opcion debe ser un valor numerico");
            }

        } while (opcion < 0 || opcion > 11);
        return opcion;

    }
}