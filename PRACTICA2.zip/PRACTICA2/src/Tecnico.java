import java.time.LocalDate;

public class Tecnico extends Persona{
    public Tecnico(String nombre, String telefono, LocalDate fechaNacimiento, String dni, CuentaBancaria cuentaBancaria) {
        super(nombre, telefono, fechaNacimiento, dni, cuentaBancaria);
    }

    @Override
    public String toString() {
        return  nombre + " Tecnico " + contrato.getPuesto() + contrato.getFechaAlta().getDayOfMonth() + "/ " +
                + contrato.getFechaAlta().getMonthValue() +  "/"+  contrato.getFechaAlta().getYear();
    }
}
