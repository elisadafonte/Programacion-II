public class CuentaBancaria {
    private String nombreEntidad;
    private String iban;

    public CuentaBancaria(String nombreEntidad, String iban) {
        this.nombreEntidad = nombreEntidad;
        this.iban = iban;
    }

    public String getNombreEntidad() {
        return nombreEntidad;
    }

    public void setNombreEntidad(String nombreEntidad) {
        this.nombreEntidad = nombreEntidad;
    }

    public String getIban() {
        return iban;
    }

    public void setIban(String iban) {
        this.iban = iban;
    }

    @Override
    public String toString() {
        return "CuentaBancaria{" +
                "nombreEntidad='" + nombreEntidad + '\'' +
                ", iban='" + iban + '\'' +
                '}';
    }
}
