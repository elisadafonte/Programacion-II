import java.io.Serializable;

abstract class Streaming implements Serializable {
    private String titulo;
    private String director;
    private TipoClasificacion clasificacion;

    public Streaming(String titulo, String director, TipoClasificacion clasificacion) {
        setTitulo(titulo);
        setDirector(director);
        setClasificacion(clasificacion);
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getDirector() {
        return director;
    }

    public void setDirector(String director) {
        this.director = director;
    }


    public void setClasificacion(TipoClasificacion clasificacion) {
        this.clasificacion = clasificacion;
    }

    @Override
    public String toString() {
        return  titulo  +
                ", " + director +
                ", " + clasificacion +
                '\n';
    }
}
