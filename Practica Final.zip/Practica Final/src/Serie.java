import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;

public class Serie extends Streaming implements Serializable {
    private ArrayList<Capitulo> capitulos;


    public Serie(String titulo, String director, TipoClasificacion clasificacion) {
        super(titulo, director, clasificacion);
        capitulos = new ArrayList<>();
    }


    public void anadirCapitulo(int temporada, int numCapitulo, int anio, String titulo) throws StreamingNoValidaException {

        if (capitulos.isEmpty()){
            capitulos.add(new Capitulo(temporada,numCapitulo,anio,titulo));
        }
        else{
            for (int i = 0; i < numCapitulos(); i++) {
                if (( capitulos.get(i).getNumeroCapitulo()==numCapitulo
                && capitulos.get(i).getTemporada()==temporada)){
                    throw new StreamingNoValidaException("Ya existe el capitulo.");
                }
            }
            capitulos.add(new Capitulo(temporada,numCapitulo,anio,titulo));
        }
    }


    public void anadirValoracion (int numCap, int temp, LocalDate fecha, int valoracion) throws ValoracionNoValidaException {
        if(capitulos.isEmpty()){
            throw new ValoracionNoValidaException("No se pudo realizar la accion con los datos dados.");
        }
        for (int i = 0; i < numCapitulos(); i++) {
            if (capitulos.get(i).getTemporada()==temp
            && capitulos.get(i).getNumeroCapitulo()==numCap){
                capitulos.get(i).anadirValoracion(new Valoracion(fecha, valoracion));
            }
        }
    }

    public int anioInicio(){
        if (capitulos.isEmpty()){
            return 0;
        }else{
            int anio =100000;
            for (int i = 0; i < numCapitulos() ; i++) {
                if (capitulos.get(i).getAnio()<anio){
                  anio=capitulos.get(i).getAnio();
                }
            }
            return anio;
        }
    }

    public double valoracionMediaTemporada (int numTemp) throws ValoracionNoValidaException {
        if (capitulos.isEmpty()){
            throw new ValoracionNoValidaException("No se pudo realizar la accion por insuficiencia de datos.");
        }
        else{
            int capituls=0;
            int subtotal=0;

            for (int i = 0; i < numCapitulos(); i++) {
                if (capitulos.get(i).getTemporada()==numTemp){
                    for (int j = 0; j < capitulos.get(i).getValoraciones().size()-1; j++) {
                        capituls++;
                        subtotal+=capitulos.get(i).getValoraciones().get(j).getValoracion();
                    }
                }
            }
            return ((subtotal+1)/(capituls+1));
        }
    }

    public int numCapitulos (){
        if (capitulos.isEmpty()){
            return 0;
        }
        else{
            return (capitulos.size());
        }
    }

    public ArrayList<Capitulo> getCapitulos() {
        return capitulos;
    }

}
