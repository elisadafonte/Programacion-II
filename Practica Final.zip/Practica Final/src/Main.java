import java.io.*;
import java.time.LocalDate;
import java.util.ArrayList;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {

        try {
            ArrayList<Streaming> streaming = new ArrayList<>();
            streaming.add((new Pelicula("La novia cadaver", "Tim Burton", TipoClasificacion.JUVENIL, 2007)));
            streaming.add((new Pelicula("Pesadilla antes de navidad", "Tim Burton", TipoClasificacion.JUVENIL, 2007)));
            streaming.add((new Serie("Shameless", "Desconocido", TipoClasificacion.JUVENIL)));

            Serie miSerie = (Serie) streaming.get(2);
            miSerie.anadirCapitulo(1, 1, 2017, "hola");
            miSerie.anadirCapitulo(2, 1, 2020, "adios");

            try {
                miSerie.anadirValoracion(1, 1, LocalDate.of(2021, 1, 1), 8);
                miSerie.anadirValoracion(1, 1, LocalDate.of(2021, 3, 4), 6);
                miSerie.anadirValoracion(1, 1, LocalDate.of(2021, 7, 10), 10);

                miSerie.anadirValoracion(1, 2, LocalDate.of(2021, 1, 1), 8);
                miSerie.anadirValoracion(1, 2, LocalDate.of(2021, 3, 4), 6);
                miSerie.anadirValoracion(1, 2, LocalDate.of(2021, 7, 10), 10);



                for (int i = 0; i < streaming.size(); i++) {
                    if (streaming.get(i) instanceof  Serie){
                        Serie serie1 = (Serie) streaming.get(i);
                        System.out.println(serie1);
                        for (int j = 0; j < serie1.numCapitulos(); j++) {
                            if (serie1.getCapitulos().get(j).valoracionMedia()>=7) {
                                System.out.println(miSerie.getCapitulos().get(j));
                            }
                        }
                    }
                }


                String archivoBinario = "miMediateca.med";
                String archivoTexto = "Informe_medios.txt";


                //SERIALIZAR A ARCHIVO BINARIO (OBJECTOUTPUTSTREAM)
                try{
                    FileOutputStream fos = new FileOutputStream(archivoBinario);
                    ObjectOutputStream oos = new ObjectOutputStream(fos);
                    oos.writeObject(streaming);
                    oos.close();
                } catch (IOException e) {
                    System.out.println("Error al guardar: " + e.getMessage());
                }


                //LEER DEL ARCHIVO BINARIO
                ArrayList<Streaming> listaLeida = null;
                try{
                    FileInputStream fis = new FileInputStream(archivoBinario);
                    ObjectInputStream ois = new ObjectInputStream(fis);
                    listaLeida = (ArrayList<Streaming>) ois.readObject();
                    ois.close();

                } catch (IOException e) {
                    System.out.println("Error al leer. "+e.getMessage());;
                } catch (ClassNotFoundException e) {
                    System.out.println("Clase no encontrada.");;
                }


                //MOSTRAR EL CONTENIDO DEL ARCHIVO BINARIO POR PANTALLA
                if (listaLeida!=null){
                    System.out.println("Peliculas");
                    for (int i = 0; i < listaLeida.size(); i++) {
                        if (listaLeida.get(i) instanceof Pelicula){
                            System.out.println(listaLeida.get(i).getTitulo()
                            + ", dirigida por "+ listaLeida.get(i).getDirector()
                            + " ("+ ((Pelicula) listaLeida.get(i)).getAnio() + ")");
                        }
                    }
                    System.out.println("\nSeries");
                    for (int i = 0; i < listaLeida.size(); i++) {
                        if (listaLeida.get(i) instanceof Serie){
                            System.out.println(listaLeida.get(i).getTitulo()
                                    + ". dirigida por "+ listaLeida.get(i).getDirector() +".");
                            for (int j = 0; j < ((Serie) listaLeida.get(i)).numCapitulos(); j++) {
                                System.out.println("Temporada "+((Serie) listaLeida.get(i)).getCapitulos().get(j).getTemporada()
                                + ", Capitulo "+((Serie) listaLeida.get(i)).getCapitulos().get(j).getNumeroCapitulo()
                                +": "+((Serie) listaLeida.get(i)).getCapitulos().get(j).getTitulo()+ ". ("
                                +((Serie) listaLeida.get(i)).getCapitulos().get(j).getAnio() + ")");
                            }

                        }
                    }
                }


                //ESCRIBIR EN UN ARCHIVO DE TEXTO (.TXT)
                try{
                    PrintWriter pw = new PrintWriter(archivoTexto);
                    pw.println("Peliculas");
                    for (int i = 0; i < listaLeida.size(); i++) {
                        if (listaLeida.get(i) instanceof Pelicula){
                            pw.println("   "+listaLeida.get(i).getTitulo()
                                    + ", dirigida por "+ listaLeida.get(i).getDirector()
                                    + " ("+ ((Pelicula) listaLeida.get(i)).getAnio() + ")");
                        }
                    }
                    pw.println("\nSeries");
                    for (int i = 0; i < listaLeida.size(); i++) {
                        if (listaLeida.get(i) instanceof Serie){
                            pw.println("   "+listaLeida.get(i).getTitulo()
                                    + ". dirigida por "+ listaLeida.get(i).getDirector() +".");
                            for (int j = 0; j < ((Serie) listaLeida.get(i)).numCapitulos(); j++) {
                                pw.println("     Temporada "+((Serie) listaLeida.get(i)).getCapitulos().get(j).getTemporada()
                                        + ", Capitulo "+((Serie) listaLeida.get(i)).getCapitulos().get(j).getNumeroCapitulo()
                                        +": "+((Serie) listaLeida.get(i)).getCapitulos().get(j).getTitulo()+ ". ("
                                        +((Serie) listaLeida.get(i)).getCapitulos().get(j).getAnio() + ")");
                            }

                        }
                    }
                    pw.close();
                } catch (FileNotFoundException e) {
                    System.out.println("No se pudo crear el archivo de texto.");
                }


            } catch (ValoracionNoValidaException e) {
                throw new RuntimeException(e);
            }

        } catch (StreamingNoValidaException e) {
            throw new RuntimeException(e);
        }


    }
}