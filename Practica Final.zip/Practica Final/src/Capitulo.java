import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;

public class Capitulo implements Serializable {
    private int temporada;
    private int numeroCapitulo;
    private int anio;
    private String titulo;
    private ArrayList<Valoracion> valoraciones;

    public Capitulo(int temporada, int numeroCapitulo, int anio, String titulo)
    throws StreamingNoValidaException {
        if (temporada<0 || numeroCapitulo<0 || anio<1900
        || anio>2025){
            throw new StreamingNoValidaException("Datos de Streaing no validos.");
        }

        setTemporada(temporada);
        setNumeroCapitulo(numeroCapitulo);
        setAnio(anio);
        setTitulo(titulo);
        valoraciones = new ArrayList<>();
    }

    public double valoracionMedia(){
        int subtotal=0;
        for (int i = 0; i < valoraciones.size(); i++) {
            subtotal+= valoraciones.get(i).getValoracion();
        }
        return (subtotal/(valoraciones.size()));
    }

    public int valoracionMax (){
        int valoracionMax=0;
        for (int i = 0; i < valoraciones.size()-1; i++) {
            if (valoracionMax<valoraciones.get(i).getValoracion()){
                valoracionMax=valoraciones.get(i).getValoracion();
            }
        }
        return valoracionMax;
    }

    public void anadirValoracion (Valoracion valoracion) throws ValoracionNoValidaException {
        valoraciones.add(valoracion);
    }

    public int getTemporada() {
        return temporada;
    }

    public void setTemporada(int temporada) {
        this.temporada = temporada;
    }

    public int getNumeroCapitulo() {
        return numeroCapitulo;
    }

    public void setNumeroCapitulo(int numeroCapitulo) {
        this.numeroCapitulo = numeroCapitulo;
    }

    public int getAnio() {
        return anio;
    }

    public void setAnio(int anio) {
        this.anio = anio;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public ArrayList<Valoracion> getValoraciones() {
        return valoraciones;
    }

    @Override
    public String toString() {
        return  "temporada " + temporada +
                ", capitulo " + numeroCapitulo +
                ", " + anio +
                ", " + titulo  +
                ", valoracion media " + valoracionMedia() +"\n";
    }
}
