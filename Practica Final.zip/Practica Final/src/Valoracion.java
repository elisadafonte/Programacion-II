import java.io.Serializable;
import java.time.LocalDate;

public class Valoracion implements Serializable {
    private LocalDate fecha;
    private int valoracion;

    public Valoracion(LocalDate fecha, int valoracion)
            throws ValoracionNoValidaException{
        if (0>valoracion||valoracion>10
        ||fecha.isAfter(LocalDate.now())
        ||fecha.isBefore(LocalDate.of(1900, 1, 1))){
        throw new ValoracionNoValidaException ("Datos de la valoracion no validos");
        }

        setFecha(fecha);
        setValoracion(valoracion);
    }
    

    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }

    public int getValoracion() {
        return valoracion;
    }

    public void setValoracion(int valoracion) {
        this.valoracion = valoracion;
    }
}
