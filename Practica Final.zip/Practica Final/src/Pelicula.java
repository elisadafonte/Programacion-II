import java.io.Serializable;
import java.util.ArrayList;

public class Pelicula extends Streaming implements Serializable {
    private int anio;
    private ArrayList<Valoracion> valoraciones;

    public Pelicula(String titulo, String director, TipoClasificacion clasificacion, int anio)
    throws StreamingNoValidaException {
        super(titulo, director, clasificacion);
        if (anio<1900 || anio>2025){
            throw new StreamingNoValidaException("Los datos del Streaming no son validos.");
        }
        setAnio(anio);
        valoraciones = new ArrayList<>();
    }

    public int getAnio() {
        return anio;
    }

    public void setAnio(int anio) {
        this.anio = anio;
    }
}
