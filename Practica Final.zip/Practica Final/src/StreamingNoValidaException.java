public class StreamingNoValidaException extends Exception{
    public StreamingNoValidaException(String message) {
        super(message);
    }
}
