//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {

        double uno = 0;
        double dos;
        System.out.println("La variable vale " + uno);

        dos = 3;
        System.out.println("La variable dos vale " + dos);

        char c1 = 'a';
        char c2 = 'b';
        System.out.println("Puedo sumar dos char " + (c1+c2));

        boolean bien = true;
        boolean mal = false;
        System.out.print("Primero vale " + bien);
        System.out.println(" y luego vale " + mal);

        System.out.println("\n FIN DEL PROGRAMA");

    }
}