import java.util.ArrayList;
import java.util.Scanner;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {

        Scanner teclado = new Scanner(System.in);
        try {
            ArrayList<Publicacion> publicaciones = new ArrayList<>(0);
            publicaciones.add(new Libro("Mario Bennedetti", "La Tregua", 1960, 208));
            publicaciones.add(new Audiolibro("Platon", "La apologia de Socrates",393, 102 ));
            publicaciones.add(new Ebook("Carmen Martin Gaite", "Caperucita en Manhattan", 1990, 123));

            for (int i = 0; i < publicaciones.size(); i++) {
                System.out.println(publicaciones.get(i));
            }

            System.out.print("Introduzca el nombre del autor: ");
            String nombre = teclado.nextLine();
            for (int i = 0; i < publicaciones.size(); i++) {
                if (publicaciones.get(i).getAutor().contains(nombre)){
                    System.out.println(publicaciones.get(i));
                }
            }

            System.out.print("Introduzca el anno: ");
            int anno = teclado.nextInt();
            int minutos=0;
            int paginas =0;
            int MG=0;
            System.out.println("Las publicaciones anteriores al anno "+anno+" son:");
            for (int i = 0; i < publicaciones.size(); i++) {
                if (anno > publicaciones.get(i).getAnnoPublicacion()) {
                    System.out.println(publicaciones.get(i).getTitulo());
                    if (publicaciones.get(i) instanceof Libro){
                        paginas += ((Libro) publicaciones.get(i)).getPaginas();
                    }
                    if (publicaciones.get(i) instanceof Audiolibro){
                        minutos += ((Audiolibro) publicaciones.get(i)).getDuracionMins();
                    }
                    if (publicaciones.get(i) instanceof Ebook){
                        MG += ((Ebook) publicaciones.get(i)).getTamannoMB();
                    }
                }
            }
            System.out.println("Paginas de los libros: "+paginas+
                    "\nMinutos de los audiolibros: "+minutos+
                    "\nTamanno de los Ebook: "+MG);


        }
        catch (Exception e){
            System.out.println("Ha habido un error.");
        }
    }
}