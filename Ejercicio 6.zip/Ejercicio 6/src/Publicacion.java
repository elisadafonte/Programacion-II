public class Publicacion {
    String autor;
    String titulo;
    int annoPublicacion;

    public Publicacion(String autor, String titulo, int annoPublicacion) {
        setAutor(autor);
        setTitulo(titulo);
        setAnnoPublicacion(annoPublicacion);
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public int getAnnoPublicacion() {
        return annoPublicacion;
    }

    public void setAnnoPublicacion(int annoPublicacion) {
        this.annoPublicacion = annoPublicacion;
    }

}
