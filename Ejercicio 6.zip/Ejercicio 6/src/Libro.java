public class Libro extends Publicacion{
    int paginas;

    public Libro(String autor, String titulo, int annoPublicacion, int paginas) throws Exception {
        super(autor, titulo, annoPublicacion);
        if (paginas>0) {
            setPaginas(paginas);
        }else {
            throw new Exception("Libro: Numero de paginas negativo.");
        }
    }

    public int getPaginas() {
        return paginas;
    }

    public void setPaginas(int paginas) {
        this.paginas = paginas;
    }

    @Override
    public String toString() {
        return "Libro: " +
                "\n Autor: " + autor + '\'' +
                "\n Titulo: " + titulo + '\'' +
                "\n Anno Publicacion: " + annoPublicacion +
                "\n Paginas: " + paginas;
    }
}
