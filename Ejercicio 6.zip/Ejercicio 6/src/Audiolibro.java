public class Audiolibro extends Publicacion {
    int duracionMins;

    public Audiolibro(String autor, String titulo, int annoPublicacion, int duracionMins) throws Exception {
        super(autor, titulo, annoPublicacion);
        if(duracionMins>0) {
            setDuracionMins(duracionMins);
        }else{
            throw new Exception("AudioLibro: duracion negativa.");
        }
    }

    public int getDuracionMins() {
        return duracionMins;
    }

    public void setDuracionMins(int duracionMins) {
        this.duracionMins = duracionMins;
    }

    @Override
    public String toString() {
        return "Audiolibro: " +
                "\n Autor: " + autor + '\'' +
                "\n Titulo: " + titulo + '\'' +
                "\n Anno Publicacion: " + annoPublicacion +
                "\n Duracion en Minutos:" + duracionMins;
    }
}
