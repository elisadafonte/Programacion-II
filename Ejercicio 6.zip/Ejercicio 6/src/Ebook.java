public class Ebook extends Publicacion{
    int tamannoMB;

    public Ebook(String autor, String titulo, int annoPublicacion, int tamannoMB) throws Exception {
        super(autor, titulo, annoPublicacion);
        if(tamannoMB>0) {
            setTamannoMB(tamannoMB);
        }else{
            throw new Exception("Ebook: tamanno negativo.");
        }
    }

    public int getTamannoMB() {
        return tamannoMB;
    }

    public void setTamannoMB(int tamannoMB) {
        this.tamannoMB = tamannoMB;
    }

    @Override
    public String toString() {
        return "Ebook: " +
                "\n Autor: " + autor + '\'' +
                "\n Titulo: " + titulo + '\'' +
                "\n Anno Publicacion: " + annoPublicacion +
                "\n Tamanno en MB: " + tamannoMB;
    }
}
