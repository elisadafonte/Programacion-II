import java.io.Serializable;
import java.util.ArrayList;

public class Polilinea implements Serializable {
    private ArrayList<Punto> puntos;

    public Polilinea() {
        puntos = new ArrayList<>();
    }

    public void addPunto (Punto punto){
        puntos.add(punto);
    }

    public int numSegmentos (){
        return puntos.isEmpty() ? 0 : (puntos.size()-1);
    }

    public double longitud (){
        double longitud = 0;

            for (int i = 0; i < puntos.size()-1; i++) {

                longitud += puntos.get(i).distancia(puntos.get(i + 1));

            }

        return longitud;
    }

    @Override
    public String toString() {
        String texto = "";
        texto += "--------------------------------------------------\n";
        texto += "| Consta de " + puntos.size() + " puntos                             |\n";
        texto += "--------------------------------------------------\n";
        texto += "|     X     |     Y     ||     X     |     Y     |\n";
        texto += "--------------------------------------------------\n";

        for (int i = 0; i < puntos.size(); i += 2) {
            Punto p1 = puntos.get(i);
            String x1 = formatea(p1.getX());
            String y1 = formatea(p1.getY());

            String x2 = "         ";
            String y2 = "         ";
            if (i + 1 < puntos.size()) {
                Punto p2 = puntos.get(i + 1);
                x2 = formatea(p2.getX());
                y2 = formatea(p2.getY());
            }

            texto += "| " + x1 + " | " + y1 + " || " + x2 + " | " + y2 + " |\n";
        }

        texto += "--------------------------------------------------\n";
        return texto;
    }

    private String formatea(double valor) {
        // Convertimos a string con 3 decimales sin usar format
        int parteEntera = (int) valor;
        double resto = valor - parteEntera;
        int decimales = (int) (resto * 1000);

        String resultado = parteEntera + ",";

        if (decimales < 10) {
            resultado += "00" + decimales;
        } else if (decimales < 100) {
            resultado += "0" + decimales;
        } else {
            resultado += decimales;
        }

        // Alinear a 7 caracteres mínimo
        while (resultado.length() < 7) {
            resultado = " " + resultado;
        }

        return resultado;
    }

    public Punto get (int indice){
        return puntos.get(indice);
    }
}
