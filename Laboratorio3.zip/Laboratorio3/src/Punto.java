import java.io.Serializable;

public class Punto implements Serializable {
    private double x;
    private double y;

    public Punto(double x, double y) {
        setX(x);
        setY(y);
    }

    public double getX() {
        return x;
    }

    public void setX(double x) {
        this.x = x;
    }

    public double getY() {
        return y;
    }

    public void setY(double y) {
        this.y = y;
    }

    public double distancia (Punto punto){
        double distanciaX = this.x - punto.getX();
        double distanciaY = this.y - punto.getY();
        double subtotal = ((distanciaX*distanciaX)+(distanciaY*distanciaY));
        double distanciaTotal = Math.sqrt(subtotal);
        return distanciaTotal;
    }

    @Override
    public String toString() {
        return "(" + getX() +
                ", " + getY() +
                ")";
    }


}
