import java.io.*;
import java.util.ArrayList;
import java.util.Random;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {


            Polilinea polilinea = new Polilinea();

            polilinea.addPunto(new Punto (1.2, 3.4));
            System.out.println(polilinea);
            polilinea.addPunto(new Punto (2.4, 3.5));
            System.out.println(polilinea);
            polilinea.addPunto(new Punto (0.5, 2.9));
            System.out.println(polilinea);
            polilinea.addPunto(new Punto (4.1, 2.4));
            System.out.println(polilinea);
            polilinea.addPunto(new Punto (3.6, 1.3));
            System.out.println(polilinea);


            System.out.println("La longitud total de la polilinea es: "+ polilinea.longitud());

            Punto punto = new Punto(8.27, 4.56);

            double subtotal=0;

            for (int i = 0; i < polilinea.numSegmentos()+1; i++) {
                subtotal+= polilinea.get(i).distancia(punto);
            }

            double media = subtotal / polilinea.numSegmentos()+1;

            System.out.println("La distancia media entre el punto "+punto.toString()+" y los puntos de la la polilinea es: "+ media);


            Random rand = new Random();

            ArrayList<Polilinea> misLineas = new ArrayList<>();

            String archivoBinario = "polilíneas.pol";
            String archivoTexto = "listado_polilineas.txt";


            for (int i = 0; i < 3; i++) {
                    Polilinea poli = new Polilinea();
                    int numPuntos = 3 + rand.nextInt(3); // 3, 4 o 5 puntos

                    for (int j = 0; j < numPuntos; j++) {
                            double x = Math.round(rand.nextDouble() * 1000) / 10.0;
                            double y = Math.round(rand.nextDouble() * 1000) / 10.0;
                            poli.addPunto(new Punto(x, y));
                    }

                    misLineas.add(poli);
            }

            // Serializar a archivo binario
            try {
                    FileOutputStream fos = new FileOutputStream("C:\\Users\\elisa\\OneDrive\\Documentos\\INF+ADE\\CUATRI 2 - 1º\\Programacion 1\\polilineas.txt");
                    ObjectOutputStream oos = new ObjectOutputStream(fos);
                    oos.writeObject(misLineas);
                    oos.close();
            } catch (IOException e) {
                    System.out.println("Error al guardar: " + e.getMessage());
            }

            // Leer del archivo
            ArrayList<Polilinea> listaLeida = null;
            try {
                    FileInputStream fis = new FileInputStream("C:\\Users\\elisa\\OneDrive\\Documentos\\INF+ADE\\CUATRI 2 - 1º\\Programacion 1\\polilineas.txt");
                    ObjectInputStream ois = new ObjectInputStream(fis);
                    listaLeida = (ArrayList<Polilinea>) ois.readObject();
                    ois.close();
            } catch (IOException e) {
                    System.out.println("Error al leer: " + e.getMessage());
            } catch (ClassNotFoundException e) {
                    System.out.println("Clase no encontrada.");
            }

            // Mostrar por pantalla
            if (listaLeida != null) {
                    for (int i = 0; i < listaLeida.size(); i++) {
                            System.out.println("--------------------------------------------------");
                            System.out.println("| Polilínea " + (i + 1) + "                                    |");
                            System.out.print(listaLeida.get(i));
                    }
            }

            // Escribir en archivo de texto
            try {
                    PrintWriter pw = new PrintWriter(archivoTexto);
                    for (int i = 0; i < listaLeida.size(); i++) {
                            pw.println("--------------------------------------------------");
                            pw.println("| Polilínea " + (i + 1) + "                                    |");
                            pw.print(listaLeida.get(i));
                    }
                    pw.close();
            } catch (FileNotFoundException e) {
                    System.out.println("No se pudo crear el archivo de texto.");
            }

    }
}